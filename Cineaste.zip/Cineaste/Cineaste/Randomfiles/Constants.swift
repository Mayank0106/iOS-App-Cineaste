//
//  Constants.swift
//  Cineaste
//
//  Created by Mayank Sharma on 14/05/20.
//  Copyright © 2020 Mayank Sharma. All rights reserved.
//

import Foundation



struct Constants {
     
    static let baseUrl = "https://image.tmdb.org/t/p/w500"
    
    static let mainURL1 = "https://api.themoviedb.org/3/movie/"
    
    static let mainURL2 = "/videos?api_key=8efe9663738c034166653c595112a697&language=en-US"
    
    
    struct Storyboard {
        
        
       static let homeViewController = "HomeVC"
        
    }
    
}
