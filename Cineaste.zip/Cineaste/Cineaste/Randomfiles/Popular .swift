//
//  Popular .swift
//  Cineaste
//
//  Created by Mayank Sharma on 18/05/20.
//  Copyright © 2020 Mayank Sharma. All rights reserved.
//

import Foundation

/*struct Popular {
    let original_title:String
    let vote_count:String
    let poster_path:String
    
    enum SerializationError:Error{
        case missing(String)
        case invalid(String:Any)
        
    }
    
    init(json:[String:Any]) throws{
        guard let original_title = json["original_title"] as? String else {throw SerializationError.missing("orignal title is missing")}
        
        guard let vote_count = json["vote_count"] as? String else {throw SerializationError.missing("vote count is missing")}
        
        guard let poster_path = json["poster_path"] as? String else {throw SerializationError.missing("poster is missing")}
        
        
        self.original_title = original_title
        self.vote_count = vote_count
        self.poster_path = poster_path
        
    }
    
    
    static let basepath = "https://api.themoviedb.org/3/movie/popular?api_key=8efe9663738c034166653c595112a697&language=en-US&page=1"
    
    static func movies (withPopularity popularity:String, completion:@escaping ([Popular]) ->()) {
         let url = basepath + popularity
        let request = URLRequest(url: URL(string:url)!)
        
        
        let task = URLSession.shared.dataTask(with: request) { (data:Data?, response:URLResponse?, error:Error?) in
            
            var moviesArray:[Popular] = []
            
            if let data = data {
                do {
                    if let json = try JSONSerialization.jsonObject(with: data, options: []) as? [String:Any] {
                        if let resultsMovies = json["results"] as? [String:Any]{
                            if let resultsData = resultsMovies["results"] as? [[String:Any]] {
                            
                                for dataPoint in resultsData {
                                    if let popularObject = try? Popular(json: dataPoint) {
                                        moviesArray.append(popularObject)
                                    }
                            
                            }
                            
                        }
                    }
                }
                 } catch {
                    print(error.localizedDescription)
                    
                        
                    }
                
                completion(moviesArray)
                
                }
                
            }
             task.resume()
        }
        
    
    }

    */



 
