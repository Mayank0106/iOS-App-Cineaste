//
//  TVListingViewController.swift
//  Cineaste
//
//  Created by Mayank Sharma on 11/06/20.
//  Copyright © 2020 Mayank Sharma. All rights reserved.
//

import UIKit

class TVListingViewController: UIViewController,UITableViewDelegate, UITableViewDataSource {
    
 
    
    
    var tv = [TVModal]()
    var tvair = [TVModal]()
    var tvpopular = [TVModal]()
    var tvtoprated = [TVModal]()
    
    var itemType: Int = 0

     @IBOutlet weak var tableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
            self.setNavBar(title: "TV Shows Listing")
        
        tableView.dataSource = self
        tableView.delegate = self
        
        // Do any additional setup after loading the view.
    }
    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       
        switch itemType{
        case 0:
            return tv.count
            
        case 1:
            
            return tvair.count
            
            
        case 2:
            return tvpopular.count
            
        case 3:
            
            return tvtoprated.count
            
            
        default:
            return 0
        }
        
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "Cell") as? TVListTableViewCell else {return UITableViewCell() }
        
        switch itemType {
            
        case 0 :
            //Will not highlight the cell when selected
            cell.selectionStyle = .none
            
            /*cell.lblDesc1.text = " " + "\(results[indexPath.row].id ?? 0)"*/
            cell.lblDesc.text = tv[indexPath.row].original_name ?? ""
            //cell.WatchImg.image = " " + (results[indexPath.row].posterPath ?? "")//
            let poster_path =  tv[indexPath.row].poster_path ?? ""
            if let imageURL = URL(string:Constants.baseUrl + poster_path)  {
                DispatchQueue.global().async {
                    let data = try? Data(contentsOf: imageURL)
                    if let data = data {
                        let image = UIImage(data: data)
                        DispatchQueue.main.async {
                            cell.WatchImg.image = image
                        }
                    }
                }
            }
            
            
        case 1 :
            
            //Will not highlight the cell when selected
            cell.selectionStyle = .none
            
            /*cell.lblDesc1.text = " " + "\(results[indexPath.row].id ?? 0)"*/
            cell.lblDesc.text = tvair[indexPath.row].original_name ?? ""
            //cell.WatchImg.image = " " + (results[indexPath.row].posterPath ?? "")//
            if let imageURL = URL(string:Constants.baseUrl + (tvair[indexPath.row].poster_path)!)  {
                DispatchQueue.global().async {
                    let data = try? Data(contentsOf: imageURL)
                    if let data = data {
                        let image = UIImage(data: data)
                        DispatchQueue.main.async {
                            cell.WatchImg.image = image
                        }
                    }
                }
            }
            
        case 3 :
            
            
            //Will not highlight the cell when selected
            cell.selectionStyle = .none
            
            /*cell.lblDesc1.text = " " + "\(results[indexPath.row].id ?? 0)"*/
            cell.lblDesc.text = tvpopular[indexPath.row].original_name ?? ""
            //cell.WatchImg.image = " " + (results[indexPath.row].posterPath ?? "")//
            if let imageURL = URL(string:Constants.baseUrl + (tvpopular[indexPath.row].poster_path)!)  {
                DispatchQueue.global().async {
                    let data = try? Data(contentsOf: imageURL)
                    if let data = data {
                        let image = UIImage(data: data)
                        DispatchQueue.main.async {
                            cell.WatchImg.image = image
                        }
                    }
                }
            }
            
            
        case 4 :
            
            
            //Will not highlight the cell when selected
            cell.selectionStyle = .none
            
            /*cell.lblDesc1.text = " " + "\(results[indexPath.row].id ?? 0)"*/
            cell.lblDesc.text = tvtoprated[indexPath.row].original_name ?? ""
            //cell.WatchImg.image = " " + (results[indexPath.row].posterPath ?? "")//
            if let imageURL = URL(string:Constants.baseUrl + (tvtoprated[indexPath.row].poster_path)!)  {
                DispatchQueue.global().async {
                    let data = try? Data(contentsOf: imageURL)
                    if let data = data {
                        let image = UIImage(data: data)
                        DispatchQueue.main.async {
                            cell.WatchImg.image = image
                        }
                    }
                }
            }
            
          
        default:
            //Will not highlight the cell when selected
            cell.selectionStyle = .none
            
            /*cell.lblDesc1.text = " " + "\(results[indexPath.row].id ?? 0)"*/
            cell.lblDesc.text = tv[indexPath.row].original_name ?? ""
            //cell.WatchImg.image = " " + (results[indexPath.row].posterPath ?? "")//
            if let imageURL = URL(string:Constants.baseUrl + (tv[indexPath.row].poster_path)!)  {
                DispatchQueue.global().async {
                    let data = try? Data(contentsOf: imageURL)
                    if let data = data {
                        let image = UIImage(data: data)
                        DispatchQueue.main.async {
                            cell.WatchImg.image = image
                        }
                    }
                }
            }
        }
        
        
        
        
        
        
        return cell
        
    }
    
}





