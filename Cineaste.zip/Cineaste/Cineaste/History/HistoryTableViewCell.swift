//
//  HistoryTableViewCell.swift
//  Cineaste
//
//  Created by Mayank Sharma on 23/05/20.
//  Copyright © 2020 Mayank Sharma. All rights reserved.
//

import UIKit
import ObjectMapper
class HistoryTableViewCell: UITableViewCell, UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout {

        var tv = [TVModal]()
    var tvair = [TVModal]()
    var tvpopular = [TVModal]()
     var tvtoprated = [TVModal]()
    var callDetailHandler: ((Int, Int) -> Void)?
    var itemType: Int = 0
     @IBOutlet weak var MycollectionView: UICollectionView!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
       
        
        self.MycollectionView.dataSource = self
        self.MycollectionView.delegate = self
        
    }
    
    //MARK:-  Handler function
    func callDetailAction(action: @escaping (Int, Int) -> Void) {
        self.callDetailHandler = action
    }
    
    //Mark Collection View Datasource and Delegate
    
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        
        return 1
    }
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        switch itemType{
        case 0:
            return tv.count
            
        case 1:
            return tvair.count
            
            
        case 2:
            return tvpopular.count
            
        case 3:
             return tvtoprated.count
       
            
        default:
            return 0
        }
        
          
    }
    
    
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return -10
        
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    
    
    
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as?  HistoryCollectionCell {
            
            
            switch itemType {
            case 0:
                
                //cell.lblDesc.text = " " + (tv[indexPath.row].original_name ?? "")
                //cell.WatchImg.image = " " + (results[indexPath.row].posterPath ?? "")
                if let imageURL = URL(string: Constants.baseUrl + tv[indexPath.row].poster_path!) {
                    DispatchQueue.global().async {
                        let data = try? Data(contentsOf: imageURL)
                        if let data = data {
                            let image = UIImage(data: data)
                            DispatchQueue.main.async {
                                cell.WatchImg.image = image
                            }
                        }
                    }
                    
                    
                    
                }
                
                
            case 1:
                
               // cell.lblDesc.text = " " + (tvair[indexPath.row].original_name ?? "")
                //cell.WatchImg.image = " " + (results[indexPath.row].posterPath ?? "")
                if let imageURL = URL(string: Constants.baseUrl + tvair[indexPath.row].poster_path!) {
                    DispatchQueue.global().async {
                        let data = try? Data(contentsOf: imageURL)
                        if let data = data {
                            let image = UIImage(data: data)
                            DispatchQueue.main.async {
                                cell.WatchImg.image = image
                            }
                        }
                    }
                    
                    
                    
                }
                
                
            case 2:
                //cell.lblDesc.text = " " + (tvpopular[indexPath.row].original_name ?? "")
                //cell.WatchImg.image = " " + (results[indexPath.row].posterPath ?? "")
                if let imageURL = URL(string: Constants.baseUrl + tvpopular[indexPath.row].poster_path!) {
                    DispatchQueue.global().async {
                        let data = try? Data(contentsOf: imageURL)
                        if let data = data {
                            let image = UIImage(data: data)
                            DispatchQueue.main.async {
                                cell.WatchImg.image = image
                            }
                        }
                    }
                    
                    
                    
                }
                
                
            case 3:
                //cell.lblDesc.text = " " + (tvtoprated[indexPath.row].original_name ?? "")
                //cell.WatchImg.image = " " + (results[indexPath.row].posterPath ?? "")
                if let imageURL = URL(string: Constants.baseUrl + tvtoprated[indexPath.row].poster_path!) {
                    DispatchQueue.global().async {
                        let data = try? Data(contentsOf: imageURL)
                        if let data = data {
                            let image = UIImage(data: data)
                            DispatchQueue.main.async {
                                cell.WatchImg.image = image
                            }
                        }
                    }
                    
                    
                    
                }
                

                
           
                
            default:
                
                
               // cell.lblDesc.text = " " + (tv[indexPath.row].original_name ?? "")
                //cell.WatchImg.image = " " + (results[indexPath.row].posterPath ?? "")
                if let imageURL = URL(string: Constants.baseUrl + tv[indexPath.row].poster_path!) {
                    DispatchQueue.global().async {
                        let data = try? Data(contentsOf: imageURL)
                        if let data = data {
                            let image = UIImage(data: data)
                            DispatchQueue.main.async {
                                cell.WatchImg.image = image
                            }
                        }
                    }
                    
                }
                
                
                
            }
            
            
            
            return cell
        }
        
        return UICollectionViewCell()
        
        
    }
    
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        // is Cancel Called
        callDetailHandler?(itemType, indexPath.row)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize{
        let size = CGSize(width: 150, height: 250)
        
        return size
    }
    
    
    
}
