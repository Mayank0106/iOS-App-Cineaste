//
//  HistoryTVInfoViewController.swift
//  Cineaste
//
//  Created by Mayank Sharma on 11/06/20.
//  Copyright © 2020 Mayank Sharma. All rights reserved.
//

import UIKit
import ObjectMapper
class HistoryTVInfoViewController: UIViewController, UICollectionViewDelegate,UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
 final let url = URL(string: "https://api.themoviedb.org/3/tv/airing_today?api_key=8efe9663738c034166653c595112a697&language=en-US&page=1")
    
    var tv: TVModal?
     var youMightLike = [TVModal]()
    
    @IBOutlet weak var ImgWa: UIImageView!
     @IBOutlet weak var cView: UICollectionView!
    @IBOutlet weak var lbl1: UILabel!
    
    @IBOutlet weak var lbl3: UILabel!
    
    /*@IBOutlet weak var celeb6: UIImageView!
    @IBOutlet weak var celeb5: UIImageView!
    @IBOutlet weak var celeb4: UIImageView!
    @IBOutlet weak var celeb3: UIImageView!
    @IBOutlet weak var celeb2: UIImageView!
    @IBOutlet weak var celeb1: UIImageView!
    */
    
    
    
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
         tvjson()
        self.cView.dataSource = self
        self.cView.delegate = self
        
        
        
       /* self.celeb1.layer.cornerRadius = 15
        self.celeb1.layer.borderWidth = 0.7
        self.celeb1.layer.borderColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        
        self.celeb2.layer.cornerRadius = 15
        self.celeb2.layer.borderWidth = 0.7
        self.celeb2.layer.borderColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        
        self.celeb3.layer.cornerRadius = 15
        self.celeb3.layer.borderWidth = 0.7
        self.celeb3.layer.borderColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        
        self.celeb4.layer.cornerRadius = 15
        self.celeb4.layer.borderWidth = 0.7
        self.celeb4.layer.borderColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        
        self.celeb5.layer.cornerRadius = 15
        self.celeb5.layer.borderWidth = 0.7
        self.celeb5.layer.borderColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        
        self.celeb6.layer.cornerRadius = 15
        self.celeb6.layer.borderWidth = 0.7
        self.celeb6.layer.borderColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        
        */
        let backdrop_path = tv?.backdrop_path ?? ""
        if let imageURL = URL(string: Constants.baseUrl + backdrop_path) {
            DispatchQueue.global().async {
                let data = try? Data(contentsOf: imageURL)
                if let data = data {
                    let image = UIImage(data: data)
                    DispatchQueue.main.async {
                        self.ImgWa.image = image
                    }
                }
            }
            
            
            
        }
        /*ImgWa.contentMode = .scaleAspectFit*/
        
        lbl1.text = tv?.original_name
        
        lbl3.text = tv?.overview
        
        
       
    }

    // tv API
    func tvjson() {
        guard let downloadURL = url else { return }
        URLSession.shared.dataTask(with: downloadURL) { data, urlResponse, error in
            guard let dataObject = data, error == nil, urlResponse != nil else {
                
                print("Something is wrong")
                
                return
                
            }
            
            
            
            print("downloaded")
            do
            {
                let json = try JSONSerialization.jsonObject(with: dataObject, options: []) as? [String : Any]
                /* let jsonData = json(using: .utf8)!*/
                guard let jsonObj = json else { return }
                var userObj = TestModaltv()
                userObj.page = jsonObj["page"] as? Int
                userObj.total_results = jsonObj["total_results"] as? Int
                userObj.total_pages = jsonObj["total_pages"] as? Int
                
                
                if let jsonResponse = jsonObj["results"] as? NSArray, let arrOfDict = jsonResponse as? [[String : Any]] {
                    let respVo = Mapper<TVModal>().mapArray(JSONArray: arrOfDict)
                    print("respVo \(respVo)")
                    userObj.tv = respVo
                    self.youMightLike = respVo
                  
                    
                }
                
                
                
                
                print("jsonResponse \t userObj", jsonObj, userObj)
                
                
                /*let decoder = JSONDecoder()
                 let results = try decoder.decode(Test123.self, from: dataObject)
                 print(results)*/
                
                DispatchQueue.main.async {
                    self.cView.reloadData()
                }
                
                
                
            }
            catch{
                print("Something wrong after downloaded")
                
            }
            
            }.resume()
        
    }
    
    
    
    
    @IBAction func playtrailer(_ sender: Any) {
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "TVWebkitViewController") as? TVWebkitViewController
        vc?.tv = self.tv!
        self.navigationController?.pushViewController(vc!, animated: true)
        
        
        
        
    }
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return youMightLike.count
    }
    
    
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 20
        
    }
    
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "Cell", for: indexPath) as?  tvYouMightLikeCollectionViewCell {
            let poster_path = youMightLike[indexPath.row].poster_path ?? ""
            if let imageURL = URL(string: Constants.baseUrl +  poster_path) {
                DispatchQueue.global().async {
                    let data = try? Data(contentsOf: imageURL)
                    if let data = data {
                        let image = UIImage(data: data)
                        DispatchQueue.main.async {
                            cell.WatchImg.image = image
                        }
                    }
                }
                
            }
            
            return cell
            
        }
        
        return UICollectionViewCell()
        
        
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "HistoryTVInfoViewController") as? HistoryTVInfoViewController
        vc?.tv = tv
        self.navigationController?.pushViewController(vc!, animated: true)
    }
    
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize{
        let size = CGSize(width: 150, height:  120)
        
        return size
    }
    
    
    

}
