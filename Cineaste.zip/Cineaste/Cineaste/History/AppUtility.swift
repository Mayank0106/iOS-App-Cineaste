//
//  AppUtility.swift
//  Cineaste
//
//  Created by Mayank Sharma on 28/05/20.
//  Copyright © 2020 Mayank Sharma. All rights reserved.
//

import Foundation
import UIKit
struct AppUtility {
    
    
    static func appDelegate () -> AppDelegate? {
        if let appDelegateValue = UIApplication.shared.delegate as? AppDelegate {
            return appDelegateValue
        } else {
            return nil
        }
    }
    
    
    
    //MARK:- Set Nav Bar Apperance
  
    static func setNavBarAppearance() {
        UINavigationBar.appearance().tintColor = UIColor.white
        UINavigationBar.appearance().backgroundColor = UIColor.black
    }
    
    static  func setRootViewController() {
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        if KeychainWrapper.standard.hasValue(forKey: "UserInfo") == true {
            // user is already logged in,just navigate him to HomeViewController
            
            let homeVc = storyboard.instantiateViewController(withIdentifier: "HomeVC") as! HomeViewController
            
            AppUtility.appDelegate()?.window?.rootViewController = homeVc
        
            
        }  else {
            
            
            let signInVc = storyboard.instantiateViewController(withIdentifier: "signInNav") as! UINavigationController
            
            AppUtility.appDelegate()?.window?.rootViewController = signInVc
            
            
        }
        
    
    }
    
}
