//
//  UserInfo.swift
//  Cineaste
//
//  Created by Mayank Sharma on 22/05/20.
//  Copyright © 2020 Mayank Sharma. All rights reserved.
//

import Foundation

import ObjectMapper

class UserInfo: NSObject, Mappable, NSCoding {
    
    /** Email. */
    var Email: String?
    /** User_id. */
    var Userid: Int?
    /**  Password*/
    var Password: Int?
    required init?(map: Map) {
    }
    
    override init() {
        
    }
    
    func mapping(map: Map) {
        Email <- map["email"]
        Userid <- map["uid"]
        Password <- map["password"]
        
     
    }
    
    func encode(with aCoder: NSCoder) {
        
        aCoder.encode(self.Userid, forKey: "uid")
        aCoder.encode(self.Email, forKey: "email")
       aCoder.encode(self.Password, forKey: "password")
        
        
        
      
        
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        
        if let identifier = aDecoder.decodeObject(forKey: "uid") as? Int {
            self.Userid = identifier
        }
        
       
        if let emailStr = aDecoder.decodeObject(forKey: "email") as? String {
            self.Email = emailStr
        }
        
        if let Passwrd = aDecoder.decodeObject(forKey: "password") as? Int {
            self.Password = Passwrd
        }
    
    func encodeToJSON() -> [String: Any] {
        return self.toJSON()
    }

   }
}
