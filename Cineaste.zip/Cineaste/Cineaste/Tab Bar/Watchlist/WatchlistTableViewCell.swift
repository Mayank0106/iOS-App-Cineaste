//
//  WatchlistCell.swift
//  Cineaste
//
//  Created by Mayank Sharma on 13/05/20.
//  Copyright © 2020 Mayank Sharma. All rights reserved.
//

import UIKit
import ObjectMapper


class WatchlistTableViewCell: UITableViewCell, UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout {
   
    
    var results = [ResultModal]()
    var topRated = [ResultModal]()
    var dailyTrending = [ResultModal]()
    var weeklyTrending = [ResultModal]()
    var callDetailHandler: ((Int, Int) -> Void)?
    var itemType: Int = 0
    
    @IBOutlet weak var MycollectionView: UICollectionView!
    
   

   
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
      
        
        self.MycollectionView.dataSource = self
        self.MycollectionView.delegate = self
        
    
      
        
    }
    //MARK:-  Handler function
    func callDetailAction(action: @escaping (Int, Int) -> Void) {
        self.callDetailHandler = action
    }
    
    
    //Mark Collection View Datasource and Delegate
    
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        
        return 1
    }
    
    
   func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        switch itemType{
            case 0:
             return results.count
            
        case 1:
          
            return topRated.count
            
            
            case 2:
             return dailyTrending.count
            
        case 3:
            
            return weeklyTrending.count
            
        
        default:
            return 0
    }
        
      
        
        
    }
    
    
    
   func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return -10
        
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    
    
   
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as?  WatchlistCollectionCell {
           
            
            switch itemType {
            case 0:
                
                //cell.lblDesc.text = " " + (results[indexPath.row].originalTitle ?? "")
                //cell.WatchImg.image = " " + (results[indexPath.row].posterPath ?? "")
                if let imageURL = URL(string: Constants.baseUrl + results[indexPath.row].posterPath!) {
                    DispatchQueue.global().async {
                        let data = try? Data(contentsOf: imageURL)
                        if let data = data {
                            let image = UIImage(data: data)
                            DispatchQueue.main.async {
                                cell.WatchImg.image = image
                            }
                        }
                    }
                    
                    
                    
                }

            case 1:
                
               // cell.lblDesc.text = (topRated[indexPath.row].originalTitle ?? "")
                //cell.WatchImg.image = " " + (results[indexPath.row].posterPath ?? "")
                if let imageURL = URL(string: Constants.baseUrl + topRated[indexPath.row].posterPath!) {
                    DispatchQueue.global().async {
                        let data = try? Data(contentsOf: imageURL)
                        if let data = data {
                            let image = UIImage(data: data)
                            DispatchQueue.main.async {
                                cell.WatchImg.image = image
                            }
                        }
                    }
                    
                }
                
                
                
            case 2:
                
                //cell.lblDesc.text = " " + (dailyTrending[indexPath.row].originalTitle ?? "")
                //cell.WatchImg.image = " " + (results[indexPath.row].posterPath ?? "")
                if let imageURL = URL(string: Constants.baseUrl + dailyTrending[indexPath.row].posterPath!) {
                    DispatchQueue.global().async {
                        let data = try? Data(contentsOf: imageURL)
                        if let data = data {
                            let image = UIImage(data: data)
                            DispatchQueue.main.async {
                                cell.WatchImg.image = image
                            }
                        }
                    }
                    
                }
           
                
            case 3:
                
                //cell.lblDesc.text = " " + (weeklyTrending[indexPath.row].originalTitle ?? "")
                //cell.WatchImg.image = " " + (results[indexPath.row].posterPath ?? "")
                if let imageURL = URL(string: Constants.baseUrl + weeklyTrending[indexPath.row].posterPath!) {
                    DispatchQueue.global().async {
                        let data = try? Data(contentsOf: imageURL)
                        if let data = data {
                            let image = UIImage(data: data)
                            DispatchQueue.main.async {
                                cell.WatchImg.image = image
                            }
                        }
                    }
                    
                }
                
            
            default:
                
                
               // cell.lblDesc.text = " " + (results[indexPath.row].originalTitle ?? "")
                //cell.WatchImg.image = " " + (results[indexPath.row].posterPath ?? "")
                if let imageURL = URL(string: Constants.baseUrl + results[indexPath.row].posterPath!) {
                    DispatchQueue.global().async {
                        let data = try? Data(contentsOf: imageURL)
                        if let data = data {
                            let image = UIImage(data: data)
                            DispatchQueue.main.async {
                                cell.WatchImg.image = image
                            }
                        }
                    }
                    
                }

                
                
            }
            
            
         
             return cell
        }
        
        return UICollectionViewCell()
      
        
    }
    
    
   func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
    // is Cancel Called
    callDetailHandler?(itemType, indexPath.row)
    }
    

    
   
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize{
        let size = CGSize(width: 150, height: 250)
        
        return size
    }
   
        
        /*let view = Bundle.main.loadNibNamed("Caraousel", owner: self, options: nil)![0] as! iCarousel
        view.frame.size = CGSize(width:view.frame.size.width/2, height: 83.0)
        view.backgroundColor = UIColor.lightGray
  
        
        if let imageURL = URL(string: Constants.baseUrl + results[index].posterPath!) {
            DispatchQueue.global().async {
                let data = try? Data(contentsOf: imageURL)
                if let data = data {
                    let image = UIImage(data: data)
                    DispatchQueue.main.async {
                        //view.WatchImg.image = image
                    }
                }
            }
            
        }*/
        
     

   


}
