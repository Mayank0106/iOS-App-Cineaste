//
//  WatchlistViewController.swift
//  Cineaste
//
//  Created by Mayank Sharma on 19/05/20.
//  Copyright © 2020 Mayank Sharma. All rights reserved.
//

import UIKit
import ObjectMapper

class WatchlistViewController: UIViewController, UISearchBarDelegate, UITabBarDelegate, UITableViewDataSource, UITableViewDelegate, iCarouselDataSource, iCarouselDelegate {
    
   
    final let url = URL(string: "https://api.themoviedb.org/3/movie/popular?api_key=8efe9663738c034166653c595112a697&language=en-US&page=1")
    
       final let url1 = URL(string: "https://api.themoviedb.org/3/movie/top_rated?api_key=8efe9663738c034166653c595112a697&language=en-US&page=1")
    
       final let url2 = URL(string: "https://api.themoviedb.org/3/trending/movie/day?api_key=8efe9663738c034166653c595112a697")
    
    
    final let url3 = URL(string: "https://api.themoviedb.org/3/trending/movie/week?api_key=8efe9663738c034166653c595112a697")
    
    
    var results =  [ResultModal]()
    var topRated =  [ResultModal]()
    var dailyTrending = [ResultModal]()
    var weeklyTrending = [ResultModal]()
    
    /*var Movies = [ResultModal]()*/
    
    var index = 0
    
    @IBOutlet weak var iCarouselView: iCarousel! 
    @IBOutlet weak var searchBar: UISearchBar!
     @IBOutlet weak var WatchImg: UIImageView!
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        downloadJson()
       getjson()
        dailyjson()
        weekjson()
       self.setNavBar(title: "Movies")
      
      /* searchBar.delegate = self
       setUpSearchBar()*/
        
         iCarouselView.type = .rotary
        iCarouselView.autoscroll = -0.2
         iCarouselView.contentMode = .scaleAspectFill
         iCarouselView.isPagingEnabled = true
        
        
        
     }
    

    func downloadJson() {
        guard let downloadURL = url else { return }
        URLSession.shared.dataTask(with: downloadURL) { data, urlResponse, error in
        guard let dataObject = data, error == nil, urlResponse != nil else {
                
                print("Something is wrong")
            
                return
                
            }
            print("downloaded")
            
            do
            {
                let json = try JSONSerialization.jsonObject(with: dataObject, options: []) as? [String : Any]
               /* let jsonData = json(using: .utf8)!*/
                guard let jsonObj = json else { return }
                var userObj = TestModal()
                userObj.page = jsonObj["page"] as? Int
                userObj.total_results = jsonObj["total_results"] as? Int
                userObj.total_pages = jsonObj["total_pages"] as? Int
                
                if let jsonResponse = jsonObj["results"] as? NSArray, let arrOfDict = jsonResponse as? [[String : Any]] {
                   let respVo = Mapper<ResultModal>().mapArray(JSONArray: arrOfDict)
                   print("respVo \(respVo)")
                    userObj.results = respVo
                    self.results = respVo
                    
                    self.iCarouselView.delegate = self
                          self.iCarouselView.dataSource = self
                    self.iCarouselView.reloadData()
                }
                  //print("jsonResponse \t userObj", jsonObj, userObj)
                
        DispatchQueue.main.async {
                  
                    self.tableView.reloadData()
                    
                }
             }
            catch{
                print("Something wrong after downloaded")
                
            }
            
        }.resume()
        
    }
    
    //Top Rated API
    
    func getjson(){
         guard let downloadURL = url1 else { return }
        URLSession.shared.dataTask(with: downloadURL) { data, urlResponse, error in
            guard let dataObject = data, error == nil, urlResponse != nil else {
                
                print("Something is wrong")
                
                return
                
            }
            print("downloaded")
            do
            {
                let json = try JSONSerialization.jsonObject(with: dataObject, options: []) as? [String : Any]
                /* let jsonData = json(using: .utf8)!*/
                guard let jsonObj = json else { return }
                print("jsonObj \(jsonObj)")
                
                
                if let jsonResponse = jsonObj["results"] as? NSArray, let arrOfDict = jsonResponse as? [[String : Any]] {
                    let respVo = Mapper<ResultModal>().mapArray(JSONArray: arrOfDict)
                    self.topRated = respVo
                    
                }
                
                 print("jsonResponse \t self.topRated", self.topRated)
                
                 DispatchQueue.main.async {
               self.tableView.reloadData()
                    
                }
                
            }
            catch{
                print("Something wrong after downloaded")
                
            }
            
            }.resume()
      }
    
    //Daily Trending Movies  API
    
    func dailyjson() {
        guard let downloadURL = url2 else { return }
        URLSession.shared.dataTask(with: downloadURL) { data, urlResponse, error in
            guard let dataObject = data, error == nil, urlResponse != nil else {
                
                print("Something is wrong")
                
                return
                
            }
             print("downloaded")
            do
            {
                let json = try JSONSerialization.jsonObject(with: dataObject, options: []) as? [String : Any]
                /* let jsonData = json(using: .utf8)!*/
                guard let jsonObj = json else { return }
                var userObj = TestModal()
                userObj.page = jsonObj["page"] as? Int
                userObj.total_results = jsonObj["total_results"] as? Int
                userObj.total_pages = jsonObj["total_pages"] as? Int
                
                
                if let jsonResponse = jsonObj["results"] as? NSArray, let arrOfDict = jsonResponse as? [[String : Any]] {
                    let respVo = Mapper<ResultModal>().mapArray(JSONArray: arrOfDict)
                    print("respVo \(respVo)")
                    userObj.results = respVo
                    self.dailyTrending = respVo
                    
                }
              
                //print("jsonResponse \t userObj", jsonObj, userObj)
                
               DispatchQueue.main.async {
                    
                    self.tableView.reloadData()
               
                    
                }
             }
            catch{
                print("Something wrong after downloaded")
                
            }
            
            }.resume()
        
    }
    
    // Weekly trending Movies API
    
    func weekjson() {
        guard let downloadURL = url else { return }
        URLSession.shared.dataTask(with: downloadURL) { data, urlResponse, error in
            guard let dataObject = data, error == nil, urlResponse != nil else {
                
                print("Something is wrong")
                
                return
                
            }
          
            print("downloaded")
            do
            {
                let json = try JSONSerialization.jsonObject(with: dataObject, options: []) as? [String : Any]
                /* let jsonData = json(using: .utf8)!*/
                guard let jsonObj = json else { return }
                var userObj = TestModal()
                userObj.page = jsonObj["page"] as? Int
                userObj.total_results = jsonObj["total_results"] as? Int
                userObj.total_pages = jsonObj["total_pages"] as? Int
                
                
                if let jsonResponse = jsonObj["results"] as? NSArray, let arrOfDict = jsonResponse as? [[String : Any]] {
                    let respVo = Mapper<ResultModal>().mapArray(JSONArray: arrOfDict)
                    print("respVo \(respVo)")
                    userObj.results = respVo
                    self.weeklyTrending = respVo
                    
                }
           
                //print("jsonResponse \t userObj", jsonObj, userObj)
               
                DispatchQueue.main.async {
                    
                    self.tableView.reloadData()
                    
                }
               
            }
            catch{
                print("Something wrong after downloaded")
                
            }
            
            }.resume()
        
    }
    
   
    
   /* private func setUpSearchBar() {
        searchBar.delegate = self
    }*/
    
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 4
    }
    
   func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       return 1
    
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "Cell") as?  WatchlistTableViewCell else {return UITableViewCell() }
        
        //Will not highlight the cell when selected
        cell.selectionStyle = .none
        print("sss results")
        print(self.results)
        print("sss topRated")
        print(self.topRated)
        print("sss dailyTrending")
        print(self.dailyTrending)
        print("ss weeklyTrendings")
        print(self.weeklyTrending)
        print("sss")
        
        
        cell.results = self.results
        cell.topRated = self.topRated
         cell.dailyTrending = self.dailyTrending
        cell.weeklyTrending = self.weeklyTrending
        cell.itemType = indexPath.section
        cell.MycollectionView.reloadData()
       
        
        
       /* cell.MycollectionView.reloadSections(IndexSet(integer : 0))
        cell.MycollectionView.reloadSections(IndexSet(integer : 1))
         cell.MycollectionView.reloadSections(IndexSet(integer : 2))
          cell.MycollectionView.reloadSections(IndexSet(integer : 3))*/
        
        
        //when cancelAction
        cell.callDetailAction {(section, rowIndex) in
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let vc = storyboard.instantiateViewController(withIdentifier: "WatchlistMovieInfoViewController") as? WatchlistMovieInfoViewController
            switch section {
            case 0:
                vc?.results = self.results[rowIndex]
             case 1:
                vc?.results = self.topRated[rowIndex]
            case 2:
                vc?.results = self.dailyTrending[rowIndex]
            case 3:
                 vc?.results = self.weeklyTrending[rowIndex]
            default: break
            }
            self.navigationController?.pushViewController(vc!, animated: true)
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 250
    }

  
    
    // MARK: Table header
     func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let vwForSection = UIView()

        vwForSection.frame = CGRect(x:0 , y:0, width: 150, height: 30)
        vwForSection.backgroundColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1)
        let lblForSection = UILabel()
        let lblForSection1 = UILabel()
        index = section
      
        lblForSection.frame = CGRect(x:10 , y:0, width: 150, height: 30)
        lblForSection.textColor = .yellow
        lblForSection.font = UIFont.systemFont(ofSize: 15.0)
        
        lblForSection1.frame = CGRect(x:360 , y:0, width: 150, height: 30)
        lblForSection1.textColor = .yellow
        lblForSection1.font = UIFont.systemFont(ofSize: 15.0)
        
        switch section {
        case 0:
            lblForSection.text = ("Popular")
           lblForSection1.text = ("More")
            let tap = UITapGestureRecognizer(target: self, action: #selector(WatchlistViewController.tapFunction))
            lblForSection1.isUserInteractionEnabled = true
            lblForSection1.addGestureRecognizer(tap)
            
        case 1:
           lblForSection.text = ("Top Rated")
           lblForSection1.text = ("More")
           let tap = UITapGestureRecognizer(target: self, action: #selector(WatchlistViewController.tapFunction))
           lblForSection1.isUserInteractionEnabled = true
           lblForSection1.addGestureRecognizer(tap)

        case 2:
            lblForSection.text = ("Daily Trending")
            lblForSection1.text = ("More")
            let tap = UITapGestureRecognizer(target: self, action: #selector(WatchlistViewController.tapFunction))
            lblForSection1.isUserInteractionEnabled = true
            lblForSection1.addGestureRecognizer(tap)

        case 3:
            lblForSection.text = ("Weekly Trending")
            lblForSection1.text = ("More")
            let tap = UITapGestureRecognizer(target: self, action: #selector(WatchlistViewController.tapFunction))
            lblForSection1.isUserInteractionEnabled = true
            lblForSection1.addGestureRecognizer(tap)

        default:
            print(section)
        }

        vwForSection.addSubview(lblForSection)
         vwForSection.addSubview(lblForSection1)
        
        return vwForSection
    
}
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 44
    }
    
    
    @objc func tapFunction(sender:UITapGestureRecognizer) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "ListViewController") as? ListViewController
        
          vc?.results = results
        vc?.topRated = topRated
        vc?.dailyTrending = dailyTrending
        vc?.weeklyTrending = weeklyTrending
    
        self.navigationController?.pushViewController(vc!, animated: true)
    }
    
    
    //iCaraousel
    
    func numberOfItems(in carousel: iCarousel) -> Int {
        return results.count
    }
    
    func carousel(_ carousel: iCarousel, viewForItemAt index: Int, reusing view: UIView?) -> UIView {
        var itemView: UIImageView?
        if view == nil {
            itemView = UIImageView(frame: CGRect(x: 0, y: 0, width: UIScreen.main.bounds.width - 40, height: 150))
            itemView?.contentMode = .scaleAspectFill
            itemView?.layer.borderWidth = 3.0
            itemView?.layer.masksToBounds = true
            itemView?.layer.cornerRadius = 8.0
            itemView?.layer.borderColor = UIColor.white.cgColor
        } else {
            itemView = view as? UIImageView
        }
        itemView?.clipsToBounds = true
     if let pathUrl = results[index].backDropPath,let imageURL = URL(string: Constants.baseUrl + pathUrl) {
            
            DispatchQueue.global().async {
                let data = try? Data(contentsOf: imageURL)
                if let data = data {
                    let image = UIImage(data: data)
                    DispatchQueue.main.async {
                        itemView?.image = image
                       
                    }
                }
            }
            
        }
        
        return itemView ?? UIImageView()
        
        
    }
    
    func carousel(_ carousel: iCarousel, didSelectItemAt index: Int) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "WatchlistMovieInfoViewController") as? WatchlistMovieInfoViewController
        
            vc?.results = results[index]
        
           self.navigationController?.pushViewController(vc!, animated: true)
    }
    
    
}

extension UIViewController {
    
   func setNavBar(title: String)  {
        self.navigationController?.isNavigationBarHidden = false
        self.navigationItem.title = title
    self.navigationController?.navigationBar.barTintColor = UIColor.red
        self.navigationController?.navigationBar.tintColor =  UIColor.white
        self.navigationController?.navigationBar.setValue(true, forKey: "hidesShadow")
    
    let textAttributes = [NSAttributedStringKey.foregroundColor:UIColor.white]
    navigationController?.navigationBar.titleTextAttributes = textAttributes
    
    
    }
    
    
    
    
}







