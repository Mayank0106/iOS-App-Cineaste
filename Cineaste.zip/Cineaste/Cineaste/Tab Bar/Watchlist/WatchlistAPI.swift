//
//  WatchlistAPI.swift
//  Cineaste
//
//  Created by Mayank Sharma on 20/05/20.
//  Copyright © 2020 Mayank Sharma. All rights reserved.
//

/*import Alamofire

protocol WatchlistAPI {
    
}
extension WatchlistAPI {
    
    
}
*/
