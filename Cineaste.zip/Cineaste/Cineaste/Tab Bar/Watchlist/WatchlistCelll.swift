//
//  WatchlistCelll.swift
//  Cineaste
//
//  Created by Mayank Sharma on 04/06/20.
//  Copyright © 2020 Mayank Sharma. All rights reserved.
//

import UIKit

class WatchlistCollectionView: UICollectionViewCell {
    
    @IBOutlet weak var WatchImg: UIImageView!
    
    @IBOutlet weak var lblDesc: UILabel!
    
}
