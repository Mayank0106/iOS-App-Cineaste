//
//  WatchlistCelll.swift
//  Cineaste
//
//  Created by Mayank Sharma on 04/06/20.
//  Copyright © 2020 Mayank Sharma. All rights reserved.
//

import UIKit

class WatchlistCollectionCell: UICollectionViewCell {
    
    @IBOutlet weak var WatchImg: UIImageView!
    
    @IBOutlet weak var lblDesc: UILabel!
    
   
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        self.WatchImg.layer.borderWidth = 3.0
        self.WatchImg.layer.borderColor = UIColor.white.cgColor
    }
    
   

}
