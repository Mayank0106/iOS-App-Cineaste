//
//  YouMightlikeCollectionViewCell.swift
//  Cineaste
//
//  Created by Mayank Sharma on 23/06/20.
//  Copyright © 2020 Mayank Sharma. All rights reserved.
//

import UIKit

class YouMightlikeCollectionViewCell: UICollectionViewCell {
    
       @IBOutlet weak var WatchImg: UIImageView!
    
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        self.WatchImg.layer.borderWidth = 3.0
        self.WatchImg.layer.borderColor = UIColor.white.cgColor
    }
    
    
}
