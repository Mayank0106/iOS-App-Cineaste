//
//  WatchlistMovieInfoViewController.swift
//  Cineaste
//
//  Created by Mayank Sharma on 23/05/20.
//  Copyright © 2020 Mayank Sharma. All rights reserved.
//

import UIKit
import ObjectMapper
class WatchlistMovieInfoViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout {
   
  
    final let url = URL(string: "https://api.themoviedb.org/3/movie/popular?api_key=8efe9663738c034166653c595112a697")
   
    var youMightLike = [ResultModal]()
    var results: ResultModal?
    var topRated: ResultModal?
    var dailyTrending: ResultModal?
    var weeklyTrending: ResultModal?
    var trailer =  [ResultModal]()
   
   
    @IBOutlet weak var ImgWa: UIImageView!
    
    @IBOutlet weak var cView: UICollectionView!
    @IBOutlet weak var lbl1: UILabel!
    
    @IBOutlet weak var lbl2: UILabel!
    
    @IBOutlet weak var lbl3: UILabel!
    
    
    /*@IBOutlet weak var celeb6: UIImageView!
    @IBOutlet weak var celeb5: UIImageView!
    @IBOutlet weak var celeb4: UIImageView!
    @IBOutlet weak var celeb3: UIImageView!
    @IBOutlet weak var celeb2: UIImageView!
    @IBOutlet weak var celeb1: UIImageView!*/
    
    /*var str1: String?*/
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        downloadJson()
        
        self.cView.dataSource = self
        self.cView.delegate = self
       
        
         /*downloadJson()*/
        
        //trailerdownload()
        
       /* self.celeb1.layer.cornerRadius = 15
        self.celeb1.layer.borderWidth = 0.7
        self.celeb1.layer.borderColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        
        self.celeb2.layer.cornerRadius = 15
        self.celeb2.layer.borderWidth = 0.7
        self.celeb2.layer.borderColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        
        self.celeb3.layer.cornerRadius = 15
        self.celeb3.layer.borderWidth = 0.7
        self.celeb3.layer.borderColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        
        self.celeb4.layer.cornerRadius = 15
        self.celeb4.layer.borderWidth = 0.7
        self.celeb4.layer.borderColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        
        self.celeb5.layer.cornerRadius = 15
        self.celeb5.layer.borderWidth = 0.7
        self.celeb5.layer.borderColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        
        self.celeb6.layer.cornerRadius = 15
        self.celeb6.layer.borderWidth = 0.7
        self.celeb6.layer.borderColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        */
        
        let backDropPath = results?.backDropPath ?? ""
        if let imageURL = URL(string: Constants.baseUrl + backDropPath) {
            DispatchQueue.global().async {
                let data = try? Data(contentsOf: imageURL)
                if let data = data {
                    let image = UIImage(data: data)
                    DispatchQueue.main.async {
                        self.ImgWa.image = image
                    }
                }
            }
           
            
            
        }
         /*ImgWa.contentMode = .scaleAspectFit*/
        
       lbl1.text = results?.originalTitle
       lbl2.text = results?.originalLanguage
       lbl3.text = results?.overView
    }
    
    
    
    func downloadJson() {
        guard let downloadURL = url else { return }
        URLSession.shared.dataTask(with: downloadURL) { data, urlResponse, error in
            guard let dataObject = data, error == nil, urlResponse != nil else {
                
                print("Something is wrong")
                
                return
                
            }
            print("downloaded")
            
            do
            {
                let json = try JSONSerialization.jsonObject(with: dataObject, options: []) as? [String : Any]
                /* let jsonData = json(using: .utf8)!*/
                guard let jsonObj = json else { return }
                var userObj = TestModal()
                userObj.page = jsonObj["page"] as? Int
                userObj.total_results = jsonObj["total_results"] as? Int
                userObj.total_pages = jsonObj["total_pages"] as? Int
                
                if let jsonResponse = jsonObj["results"] as? NSArray, let arrOfDict = jsonResponse as? [[String : Any]] {
                    let respVo = Mapper<ResultModal>().mapArray(JSONArray: arrOfDict)
                    print("respVo \(respVo)")
                    userObj.results = respVo
                    self.youMightLike = respVo
                    
                   
                }
                //print("jsonResponse \t userObj", jsonObj, userObj)
                
                DispatchQueue.main.async {
                    
                    self.cView.reloadData()
                    
                }
            }
            catch{
                print("Something wrong after downloaded")
                
            }
            
            }.resume()
        
    }
    
   
    
    
    @IBAction func playTrailer(_ sender: Any) {
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "WebKitViewController") as? WebKitViewController
        vc?.result = self.results!
        self.navigationController?.pushViewController(vc!, animated: true)
        
        /* let videoURL = URL(string: "https://www.youtube.com/watch?v=pNyVfBPrXWM")
         
         "\(Constants.mainURL1) \(String(describing:  results?.id!)) \(Constants.mainURL2)"
         */
        
    }
    // Mark Collection View Data Source and Delegate
    
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
         return youMightLike.count
    }
    
    
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 20
        
    }

    
   func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }

    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "Cell", for: indexPath) as?  YouMightlikeCollectionViewCell {
            
            if let imageURL = URL(string: Constants.baseUrl + youMightLike[indexPath.row].posterPath!) {
                DispatchQueue.global().async {
                    let data = try? Data(contentsOf: imageURL)
                    if let data = data {
                        let image = UIImage(data: data)
                        DispatchQueue.main.async {
                            cell.WatchImg.image = image
                        }
                    }
                }
                
            }
         
            return cell
            
        }
        
        return UICollectionViewCell()
        
        
    }
    
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize{
        let size = CGSize(width: 150, height:  120)
        
        return size
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "WatchlistMovieInfoViewController") as? WatchlistMovieInfoViewController
        vc?.results = results
        self.navigationController?.pushViewController(vc!, animated: true)
    }
    
    
    
}

    

