//
//  Watchlist.swift
//  Cineaste
//
//  Created by Mayank Sharma on 21/05/20.
//  Copyright © 2020 Mayank Sharma. All rights reserved.
//

import Foundation
import ObjectMapper

struct ResultModal: Mappable {
   
    /** id **/
    var id: Int?
    /** original_title Name */
    var originalTitle: String?
    /** poster_path */
    var posterPath: String?
    /** Release Date */
    var releaseDate: Int?
    /** Adult */
    var Adult: String?
    /** VoteCount*/
    var voteCount: Int?
    /** backDropPath*/
    var backDropPath: String?
    /** OriginalLanguage*/
    var originalLanguage: String?
    /** OverView*/
    var overView: String?
    /** Popularity*/
    var popularity: Int?
    /** voteOverage*/
    var voteAverage: Int?
    /* key */
    var key: String?
    
    
    
    init() {
    }
    
    init?(map: Map) {
    }
    
    mutating func mapping(map: Map) {
        id <- map["id"]
        originalTitle <- map["original_title"]
        posterPath <- map["poster_path"]
        releaseDate <- map["release_date"]
        Adult <- map["adult"]
        voteCount <- map["vote_count"]
        backDropPath <- map["backdrop_path"]
        originalLanguage <- map["original_language"]
        overView <- map["overview"]
        popularity <- map ["popularity"]
        voteAverage <- map["vote_average"]
        key <- map["key"]
       
    }
    
    func encodeToJSON() -> [String: Any] {
        return self.toJSON()
    }
}



struct TestModal: Mappable {
    var page : Int?
    var total_results : Int?
    var total_pages : Int?
    var results : [ResultModal]? = [ResultModal]()
   
    
    init() {
    }
    
    init?(map: Map) {
    }
    
    mutating func mapping(map: Map) {
        page <- map["page"]
        total_results <- map["total_results"]
        total_pages <- map["total_pages"]
        results <- map["results"]
        
       
       
        
    }
    
    func encodeToJSON() -> [String: Any] {
        return self.toJSON()
    }
}












// API for TV Shows


struct TVModal : Mappable {
    var original_name : String?
    var genre_ids : [Int]?
    var name : String?
    var popularity : Double?
    var origin_country : [String]?
    var vote_count : Int?
    var first_air_date : String?
    var backdrop_path : String?
    var original_language : String?
    var id : Int?
    var vote_average : Double?
    var overview : String?
    var poster_path : String?
    var key: String?
    
    
    init() {
    }
    
    init?(map: Map) {
        
    }
    
    mutating func mapping(map: Map) {
        
        original_name <- map["original_name"]
        genre_ids <- map["genre_ids"]
        name <- map["name"]
        popularity <- map["popularity"]
        origin_country <- map["origin_country"]
        vote_count <- map["vote_count"]
        first_air_date <- map["first_air_date"]
        backdrop_path <- map["backdrop_path"]
        original_language <- map["original_language"]
        id <- map["id"]
        vote_average <- map["vote_average"]
        overview <- map["overview"]
        poster_path <- map["poster_path"]
        key <- map["key"]
    }
    
    func encodeToJSON() -> [String: Any] {
        return self.toJSON()
    }
}





struct TestModaltv : Mappable {
    var page : Int?
    var total_results : Int?
    var total_pages : Int?
    var tv : [TVModal]? = [TVModal]()
    
    
    
    init() {
    }
    
    init?(map: Map) {
        
    }
    
    mutating func mapping(map: Map) {
        
        page <- map["page"]
        total_results <- map["total_results"]
        total_pages <- map["total_pages"]
        tv <- map["tv"]
    }
    
    func encodeToJSON() -> [String: Any] {
        return self.toJSON()
    }
}




