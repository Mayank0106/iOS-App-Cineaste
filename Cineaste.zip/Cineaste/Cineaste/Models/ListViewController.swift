//
//  ListViewController.swift
//  Cineaste
//
//  Created by Mayank Sharma on 09/06/20.
//  Copyright © 2020 Mayank Sharma. All rights reserved.
//

import UIKit
import ObjectMapper
class ListViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
   
    var results = [ResultModal]()
   
    var topRated =  [ResultModal]()
    var dailyTrending = [ResultModal]()
    var weeklyTrending = [ResultModal]()
    var itemType: Int = 0

 @IBOutlet weak var tableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
         /*downloadJson()*/
        self.setNavBar(title: "Movies Listing")
        
        tableView.dataSource = self
        tableView.delegate = self
        
      
    }
    
    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch section{
        case 0:
            return results.count
            
        case 1:
            
            return topRated.count
            
            
        case 2:
            return dailyTrending.count
            
        case 3:
            
            return weeklyTrending.count
            
            
        default:
            return 0
        }
        
        
        
    }
   func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "Cell") as? ListTableViewCell else {return UITableViewCell() }
    
    
    switch itemType {
    case 0 :
        
        
        
        //Will not highlight the cell when selected
        cell.selectionStyle = .none
        
        /*cell.lblDesc1.text = " " + "\(results[indexPath.row].popularity ?? 0)"*/
        cell.lblDesc.text = results[indexPath.row].originalTitle ?? ""
        //cell.WatchImg.image = " " + (results[indexPath.row].posterPath ?? "")//
        if let imageURL = URL(string:Constants.baseUrl + (results[indexPath.row].posterPath)!)  {
            DispatchQueue.global().async {
                let data = try? Data(contentsOf: imageURL)
                if let data = data {
                    let image = UIImage(data: data)
                    DispatchQueue.main.async {
                        cell.WatchImg.image = image
                    }
                }
            }
        }
        
    case 1 :
        
        
        //Will not highlight the cell when selected
        cell.selectionStyle = .none
        
        /*cell.lblDesc1.text = " " + "\(results[indexPath.row].popularity ?? 0)"*/
        cell.lblDesc.text = topRated[indexPath.row].originalTitle ?? ""
        //cell.WatchImg.image = " " + (results[indexPath.row].posterPath ?? "")//
        if let imageURL = URL(string:Constants.baseUrl + (topRated[indexPath.row].posterPath)!)  {
            DispatchQueue.global().async {
                let data = try? Data(contentsOf: imageURL)
                if let data = data {
                    let image = UIImage(data: data)
                    DispatchQueue.main.async {
                        cell.WatchImg.image = image
                    }
                }
            }
        }
        
        
    case 2 :
        
        //Will not highlight the cell when selected
        cell.selectionStyle = .none
        
       /* cell.lblDesc1.text = " " + "\(results[indexPath.row].popularity ?? 0)"*/
        cell.lblDesc.text = dailyTrending[indexPath.row].originalTitle ?? ""
        //cell.WatchImg.image = " " + (results[indexPath.row].posterPath ?? "")//
        if let imageURL = URL(string:Constants.baseUrl + (dailyTrending[indexPath.row].posterPath)!)  {
            DispatchQueue.global().async {
                let data = try? Data(contentsOf: imageURL)
                if let data = data {
                    let image = UIImage(data: data)
                    DispatchQueue.main.async {
                        cell.WatchImg.image = image
                    }
                }
            }
        }
        
    case 3:
        
        //Will not highlight the cell when selected
        cell.selectionStyle = .none
        
       /* cell.lblDesc1.text = " " + "\(results[indexPath.row].popularity ?? 0)"*/
        cell.lblDesc.text = weeklyTrending[indexPath.row].originalTitle ?? ""
        //cell.WatchImg.image = " " + (results[indexPath.row].posterPath ?? "")//
        if let imageURL = URL(string:Constants.baseUrl + (weeklyTrending[indexPath.row].posterPath)!)  {
            DispatchQueue.global().async {
                let data = try? Data(contentsOf: imageURL)
                if let data = data {
                    let image = UIImage(data: data)
                    DispatchQueue.main.async {
                        cell.WatchImg.image = image
                    }
                }
            }
        }
        
        
        
        
    default:
        
        
            //Will not highlight the cell when selected
            cell.selectionStyle = .none
        
       /* cell.lblDesc1.text = " " + "\(results[indexPath.row].popularity ?? 0)"*/
        cell.lblDesc.text = dailyTrending[indexPath.row].originalTitle ?? ""
        //cell.WatchImg.image = " " + (results[indexPath.row].posterPath ?? "")//
        if let imageURL = URL(string:Constants.baseUrl + (dailyTrending[indexPath.row].posterPath)!)  {
            DispatchQueue.global().async {
                let data = try? Data(contentsOf: imageURL)
                if let data = data {
                    let image = UIImage(data: data)
                    DispatchQueue.main.async {
                        cell.WatchImg.image = image
                    }
                }
            }
        }
        
        
    }
    
    
        return cell
        
    }
    
    
    
    func tableView(_ tableView: UITableView, didDeselectRowAt indexPath: IndexPath) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "WatchlistMovieInfoViewController") as? WatchlistMovieInfoViewController
        
        vc?.results = results[indexPath.row]
        vc?.topRated = topRated[indexPath.row]
        vc?.dailyTrending = dailyTrending[indexPath.row]
        vc?.weeklyTrending = weeklyTrending[indexPath.row]
        
        
          self.navigationController?.pushViewController(vc!, animated: true)
    }
    

}
