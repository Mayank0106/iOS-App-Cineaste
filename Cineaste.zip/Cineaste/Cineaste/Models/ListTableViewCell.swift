//
//  ListTableViewCell.swift
//  Cineaste
//
//  Created by Mayank Sharma on 09/06/20.
//  Copyright © 2020 Mayank Sharma. All rights reserved.
//

import UIKit

class ListTableViewCell: UITableViewCell {
    
    @IBOutlet weak var WatchImg: UIImageView!
    @IBOutlet weak var lblDesc: UILabel!

    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        self.WatchImg.layer.borderWidth = 2.0
        self.WatchImg.layer.borderColor = UIColor.white.cgColor
        //lblDesc.sizeToFit()

    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
