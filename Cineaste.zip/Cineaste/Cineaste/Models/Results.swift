/* 
Copyright (c) 2020 Swift Models Generated from JSON powered by http://www.json4swift.com

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

For support, please feel free to contact me at https://www.linkedin.com/in/syedabsar

*/


import Foundation
struct Results : Codable {
	var popularity : Double?
	var vote_count : Int?
	var video : Bool?
	var poster_path : String?
	var id : Int?
	var adult : Bool?
	var backdrop_path : String?
	var original_language : String?
	var original_title : String?
	var genre_ids : [Int]?
	var title : String?
	var vote_average : Int?
	var overview : String?
	var release_date : String?
    init() {}
	enum CodingKeys: String, CodingKey {

		case popularity = "popularity"
		case vote_count = "vote_count"
		case video = "video"
		case poster_path = "poster_path"
		case id = "id"
		case adult = "adult"
		case backdrop_path = "backdrop_path"
		case original_language = "original_language"
		case original_title = "original_title"
		case genre_ids = "genre_ids"
		case title = "title"
		case vote_average = "vote_average"
		case overview = "overview"
		case release_date = "release_date"
	}

	
    
    

}
