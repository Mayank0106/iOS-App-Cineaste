//
//  TVListingTableViewCell.swift
//  Cineaste
//
//  Created by Mayank Sharma on 11/06/20.
//  Copyright © 2020 Mayank Sharma. All rights reserved.
//

import UIKit

class TVListingTableViewCell: UITableViewCell {

    @IBOutlet weak var WatchImg: UIImageView!
    @IBOutlet weak var lblDesc: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        self.WatchImg.layer.borderWidth = 2.0
        self.WatchImg.layer.borderColor = UIColor.white.cgColor
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
