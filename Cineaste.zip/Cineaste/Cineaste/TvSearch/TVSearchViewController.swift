//
//  TVSearchViewController.swift
//  Cineaste
//
//  Created by Mayank Sharma on 26/06/20.
//  Copyright © 2020 Mayank Sharma. All rights reserved.
//

import UIKit
import ObjectMapper
class TVSearchViewController: UIViewController,UITableViewDataSource, UISearchBarDelegate, UITableViewDelegate {
     final let url = URL(string: "https://api.themoviedb.org/3/tv/airing_today?api_key=8efe9663738c034166653c595112a697&language=en-US&page=1")
 private var tv = [TVModal]()
     var downnloadJson = [TVModal]()
    
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var tableView: UITableView!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
          tvjson()
        self.setNavBar1(title: "Discover TV Shows")
        
    }

    
    
    func SearchbarTapped(urlString: String) {
        
        let urlNew = URL(string: urlString)
        
        guard let downloadURL = urlNew else { return }
        
        URLSession.shared.dataTask(with: downloadURL) { data, urlResponse, error in
            guard let dataObject = data, error == nil, urlResponse != nil else {
                print("Something is wrong")
                return
            }
            print("downloaded")
            
            do
            {
                let json = try JSONSerialization.jsonObject(with: dataObject, options: []) as? [String : Any]
                
                print("respVo \(json)")
                
                /* let jsonData = json(using: .utf8)!*/
                guard let jsonObj = json else { return }
                var userObj = TestModaltv()
                userObj.page = jsonObj["page"] as? Int
                userObj.total_results = jsonObj["total_results"] as? Int
                userObj.total_pages = jsonObj["total_pages"] as? Int
                
                if let jsonResponse = jsonObj["results"] as? NSArray, let arrOfDict = jsonResponse as? [[String : Any]] {
                    let respVo = Mapper<TVModal>().mapArray(JSONArray: arrOfDict)
                    print("respVo \(respVo)")
                    userObj.tv = respVo
                    self.tv = respVo
                    
                    DispatchQueue.main.async {
                        print("responsee",respVo)
                        //if respVo.count > 0 {
                        self.tableView.reloadData()
                        //}
                    }
                }
                
            }
            catch {
                print("Something wrong after downloaded")
                
            }
            
            }.resume()
        
    }
    
    
    
    
    
    
    
    
    
    
    
    // tv API
    func tvjson() {
        guard let downloadURL = url else { return }
        URLSession.shared.dataTask(with: downloadURL) { data, urlResponse, error in
            guard let dataObject = data, error == nil, urlResponse != nil else {
                
                print("Something is wrong")
                
                return
                
            }
            
            
            
            print("downloaded")
            do
            {
                let json = try JSONSerialization.jsonObject(with: dataObject, options: []) as? [String : Any]
                /* let jsonData = json(using: .utf8)!*/
                guard let jsonObj = json else { return }
                var userObj = TestModaltv()
                userObj.page = jsonObj["page"] as? Int
                userObj.total_results = jsonObj["total_results"] as? Int
                userObj.total_pages = jsonObj["total_pages"] as? Int
                
                
                if let jsonResponse = jsonObj["results"] as? NSArray, let arrOfDict = jsonResponse as? [[String : Any]] {
                    let respVo = Mapper<TVModal>().mapArray(JSONArray: arrOfDict)
                    print("respVo \(respVo)")
                    userObj.tv = respVo
                    self.tv = respVo
                     self.downnloadJson = self.tv
                  
                }
                
                print("jsonResponse \t userObj", jsonObj, userObj)
                
                
                /*let decoder = JSONDecoder()
                 let results = try decoder.decode(Test123.self, from: dataObject)
                 print(results)*/
                
                DispatchQueue.main.async {
                    self.tableView.reloadData()
                }
                
                
                
            }
            catch{
                print("Something wrong after downloaded")
                
            }
            
            }.resume()
        
    }
    
  
    
    
    
    
    //Mark Table View DataSource and Delegate
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tv.count
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "Cell") as? TVSearchCellTableViewCell else {return UITableViewCell() }
        
        //Will not highlight the cell when selected
        cell.selectionStyle = .none
        
        
        
        cell.lblDesc.text = " " + (tv[indexPath.row].original_name ?? "")
        //cell.WatchImg.image = " " + (results[indexPath.row].posterPath ?? "")//
        
        let poster_path = tv[indexPath.row].poster_path ?? ""
        
        if let imageURL = URL(string: Constants.baseUrl +  poster_path) {
            DispatchQueue.global().async {
                let data = try? Data(contentsOf: imageURL)
                if let data = data {
                    let image = UIImage(data: data)
                    DispatchQueue.main.async {
                        cell.WatchImg.image = image
                    }
                }
            }
        }
        
        return cell
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "HistoryTVInfoViewController") as? HistoryTVInfoViewController
        vc?.tv = tv[indexPath.row]
        self.navigationController?.pushViewController(vc!, animated: true)
        
    }
    
    
    
    //Search Bar
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        
        var urlString = "https://api.themoviedb.org/3/search/tv?api_key=8efe9663738c034166653c595112a697&language=en-US&page=1&query={tv_name}&include_adult=false"
        
        //if let id = result.id {
        if let etxEmpty = searchBar.text?.isEmpty, etxEmpty {
            // Show Alert to user
        } else {
            urlString = urlString.replacingOccurrences(of: "{tv_name}", with:"\(searchBar.text!)", options: .literal, range: nil)
            
            self.SearchbarTapped(urlString: urlString)
        }
        
        
        self.searchBar.endEditing(true)
        
    }
    
    
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        
        if (searchBar.text?.isEmpty)! {
            self.tv = self.downnloadJson
            self.tableView.reloadData()
        }
        
    }
    
    
    
    
    
    
    


}


extension UIViewController {
    
    func setNavBar1(title: String)  {
        self.navigationController?.isNavigationBarHidden = false
        self.navigationItem.title = title
        self.navigationController?.navigationBar.barTintColor = UIColor.red
        self.navigationController?.navigationBar.tintColor =  UIColor.white
        self.navigationController?.navigationBar.setValue(true, forKey: "hidesShadow")
        
        let textAttributes = [NSAttributedStringKey.foregroundColor:UIColor.white]
        navigationController?.navigationBar.titleTextAttributes = textAttributes
        
        
    }
    
    
    
    
}
