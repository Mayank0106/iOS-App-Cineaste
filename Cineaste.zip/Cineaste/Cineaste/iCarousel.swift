//
//  iCarousel.swift
//  Cineaste
//
//  Created by Mayank Sharma on 11/06/20.
//  Copyright © 2020 Mayank Sharma. All rights reserved.
//

import UIKit

class iCarousel: UIView {
    
    
    
    

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
