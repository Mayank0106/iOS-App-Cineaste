//
//  HomeViewController.swift
//  Cineaste
//
//  Created by Mayank Sharma on 15/05/20.
//  Copyright © 2020 Mayank Sharma. All rights reserved.
//

import UIKit

class HomeViewController: UITabBarController   {
    
    
    
    
    /*func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
    }*/
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
       /* Popular.movies(withPopularity: "663.707") { (resultss:[Popular]) in
            for result in resultss{
                
                print("\(result)\n\n")
            }
        }*/

        // Do any additional setup after loading the view.
    }

    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
