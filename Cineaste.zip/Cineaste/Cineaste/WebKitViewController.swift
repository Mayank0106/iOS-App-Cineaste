//
//  WebKitViewController.swift
//  Cineaste
//
//  Created by Mayank Sharma on 17/06/20.
//  Copyright © 2020 Mayank Sharma. All rights reserved.
//

import UIKit
import WebKit
import ObjectMapper

class WebKitViewController: UIViewController {
    
    @IBOutlet weak var webView: WKWebView!
    var result =  ResultModal()
   
    override func viewDidLoad() {
        super.viewDidLoad()
        
        var url = "https://api.themoviedb.org/3/movie/{movie_id}/videos?api_key=8efe9663738c034166653c595112a697&language=en-US"
        
        if let movieID = self.result.id {
            url = url.replacingOccurrences(of: "{movie_id}", with:"\(movieID)", options: .literal, range: nil)
        }
        print("URL IS", url)
        trailerdownload(urlString: url)
    }

   
    func trailerdownload(urlString: String) {
        
        let url = URL(string: urlString)
        guard let downloadURL = url else { return }
        URLSession.shared.dataTask(with: downloadURL) { data, urlResponse, error in
            guard let dataObject = data, error == nil, urlResponse != nil else {
                
                print("Something is wrong")
                
                return
                
            }
            print("downloaded")
            
            do
            {
                let json = try JSONSerialization.jsonObject(with: dataObject, options: []) as? [String : Any]
                
                print("respVo \(json)")

                /* let jsonData = json(using: .utf8)!*/
                guard let jsonObj = json else { return }
                var userObj = TestModal()
                userObj.page = jsonObj["page"] as? Int
                userObj.total_results = jsonObj["total_results"] as? Int
                userObj.total_pages = jsonObj["total_pages"] as? Int
                
                if let jsonResponse = jsonObj["results"] as? NSArray, let arrOfDict = jsonResponse as? [[String : Any]] {
                     let respVo = Mapper<ResultModal>().mapArray(JSONArray: arrOfDict)
                    print("respVo \(respVo)")
                    userObj.results = respVo
                  DispatchQueue.main.async {
                        print("responsee",respVo)
                        if respVo.count > 0 {
                            self.loadWebView(result: respVo[0])
                        }
                    }
                }
                
            }
            catch {
                print("Something wrong after downloaded")
                
            }
            
            }.resume()
        
    }
    
    func loadWebView(result: ResultModal) {
        // (Constants.mainURL1)  \(String(describing: trailer?.id!)) \(Constants.mainURL2)
        var urlString = "https://www.youtube.com/embed/{movie_key}"
        if let key = result.key {
            urlString = urlString.replacingOccurrences(of: "{movie_key}", with:"\(key)", options: .literal, range: nil)
        }
        print(" Youtube URL IS", urlString)
        
        let url = URL(string: urlString)
        let request = URLRequest(url: url!)
        webView.load(request)
        
    
    }
 
    
}
