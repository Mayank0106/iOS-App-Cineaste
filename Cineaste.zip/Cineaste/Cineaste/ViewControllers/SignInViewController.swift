//
//  ViewController.swift
//  Zepplin
//
//  Created by Mayank Sharma on 25/02/20.
//  Copyright © 2020 Mayank Sharma. All rights reserved.
//

import UIKit
import FirebaseAuth
class SignInViewController: UIViewController, UITextFieldDelegate  {
    
    @IBOutlet weak var Emailtxt: UITextField!
    @IBOutlet weak var Pwdtxt: UITextField!
    @IBOutlet weak var lblDescription: UILabel!
    @IBOutlet weak var lblDescription1: UILabel!
    @IBOutlet weak var btnTwitter: UIButton!
    @IBOutlet weak var Emaill: UITextField!
    
    @IBOutlet weak var btnLinkin: UIButton!
    @IBOutlet weak var btnfb: UIButton!
    @IBOutlet weak var Pwd: UITextField!
    
    
   
    override func viewDidLoad() {
        super.viewDidLoad()
        lblDescription.isHidden = true
        self.Emailtxt.delegate = self
        self.Pwdtxt.delegate = self
        self.navigationController?.isNavigationBarHidden = true
        self.btnTwitter.layer.cornerRadius = 15
        self.btnTwitter.layer.borderWidth = 0.7
        self.btnTwitter.layer.borderColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)

        
        
        self.btnfb.layer.cornerRadius = 15
        self.btnfb.layer.borderWidth = 0.7
        self.btnfb.layer.borderColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        
        self.btnLinkin.layer.cornerRadius = 15
        self.btnLinkin.layer.borderWidth = 0.7
        self.btnLinkin.layer.borderColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        
        signInTextfield()
        
    
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    
    
    
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.view.endEditing(true)
        return false
    }
    
    @IBAction func SignInbtn(_ sender: Any) {
       
    
        
        
        
        
        //Create Cleaned Version of the text field
        let email = Emailtxt.text!.trimmingCharacters(in: .whitespacesAndNewlines)
        let password = Pwdtxt.text!.trimmingCharacters(in: .whitespacesAndNewlines)
        
        //Signing in the User
        Auth.auth().signIn(withEmail: email, password: password) {
            (result, error) in
            
            if error != nil {
                // Couldn't Sign in
                self.lblDescription.text = error!.localizedDescription
                self.lblDescription.alpha = 1
                
            }
            else {
                // Saving Email in KeyChain for AutoLogin feature.
                guard let Email = self.Emailtxt.text else { return }
                let obj: UserInfo = UserInfo()
                obj.Email = Email
                
                KeychainWrapper.standard.set(obj, forKey: "UserInfo")
                
                AppUtility.setRootViewController()
                
            }
        }
   }
    
    
    
    func signInTextfield() {
        
        
        let bottomLine = CALayer()
        let bottomLine1 = CALayer()
       
        
        bottomLine.frame = CGRect( x: 0, y: Emaill.frame.height - 2, width: Emaill.frame.width, height: 2)
        bottomLine.backgroundColor = UIColor.white.cgColor
        
    
        
        
        bottomLine1.frame = CGRect( x: 0, y: Pwd.frame.height - 2, width: Pwd.frame.width, height: 2)
        bottomLine1.backgroundColor = UIColor.white.cgColor
        
        
        //Remove Border on text field
        Emaill.borderStyle = .none
        Pwd.borderStyle = .none
        
        // Add line to the text field
        Emaill.layer.addSublayer(bottomLine)
        Pwd.layer.addSublayer(bottomLine1)
        // image on left side
        Emaill.leftViewMode = UITextFieldViewMode.always
        let imageView = UIImageView(frame: CGRect(x: 0, y: 0, width: 20, height: 20))
        let image = UIImage(named: "emaill")
        imageView.image = image
        Emaill.leftView = imageView
        
        
        Pwd.leftViewMode = UITextFieldViewMode.always
        let imageView1 = UIImageView(frame: CGRect(x: 0, y: 0, width: 20, height: 20))
        let image1 = UIImage(named: "passwordd")
        imageView1.image = image1
        Pwd.leftView = imageView1

        
        
    }
    
    
    
    
    
    
}
       
    /*lblDescription.isHidden = true
        lblDescription1.isHidden = true
        
        
        
        
        
        
       // Get the default AuthUI Object
        /*let authUI = FUIAuth.defaultAuthUI()
        guard authUI != nil else {
             Log the error
             return
        }
        
        //set ourselves as a Delegate
        
        authUI?.delegate = self
        
        //Get a refrence to authUI view Controller
        
        let authSignInViewController = authUI!.authSignInViewController()
        
        //show it
        present(authSignInViewController, animated = true, completion: nil)
        */
        
        
        /*guard let userName = self.Emailtxt.text,
            let password = self.Pwdtxt.text else { return }
        
        /*let keychain = KeychainSwift()
        keychain.accessGroup = "123ABCXYZ.iOSAppTemplates"
        keychain.set(userName, forKey: "userName")
        keychain.set(password, forKey: "password")*/
        
        guard let email = Emailtxt.text, Emailtxt.text?.characters.count !=
            0 else {
                lblDescription.isHidden = false
                lblDescription1.text = "Please enter your Email"
                return
        }
        if isValidEmail(emailID: email) == false {
            lblDescription.isHidden = false
            lblDescription.text = "Please enter valid Email address"
            
        }
        
        guard let Password = Pwdtxt.text,
            Pwdtxt.text?.characters.count != 0 else {
                lblDescription1.isHidden = false
                lblDescription1.text = "Please enter your Password"
                return
        }
        if isValidPassword(Pwd: Password) == false {
              lblDescription1.isHidden = false
              lblDescription1.text = "Please Enter a Valid Password"
            }
       // self.callSignInWebService()
    }
  
    func isValidEmail(emailID:String) ->Bool {
        let  emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9,-]+\\.[A-Za-z]{2,}"
        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailTest.evaluate(with: emailID)
    }
    
    
   func isValidPassword(Pwd:String) -> Bool {
        let passwordRegex = "^(?=.*\\d)(?=.*[a-z])(?=.*[A-Z])[0-9a-zA-Z!@#$%^&*()\\-_=+{}|?>.<,:;~`’]{8,}$"
        let PasswordTest = NSPredicate(format:"SELF MATCHES %@", passwordRegex)
        return PasswordTest.evaluate(with:Pwd)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

/*extension SignInViewController: FUIAuthDelegate {
    func authUI(_ authUI: FUIAuth, didSignInWith authDataResult: AuthDataResult?, error: Error?) {
        
        //check if there was an error
        
        if error != nil {
            // Log error
            
            return
        }
        
        // authDataResult?.user.uid
        
        performSegue(withIdentifier: "goHome", sender: self)
    }
}
*/


/*extension SignInViewController: SignInAPI {
    /// Create Device Info Object
    ///
    /// - Returns: Device Info Object
    func createDeviceInfoObject() -> DeviceInfo {
        
        var deviceInfo = DeviceInfo()
        
        let strDeviceID = UIDevice.current.identifierForVendor?.uuidString
        deviceInfo.deviceId = strDeviceID
        deviceInfo.deviceType = 2 // for iPhone
        deviceInfo.deviceToken = "2347823478989423789234789234789"
        deviceInfo.deviceOS = UIDevice.current.systemVersion
        return deviceInfo
        
    }
    
    // MARK: - Create User model
    
    /// Create User Model
    ///
    /// - Returns: user model
    func createUserModel() -> UserDeviceModel {
        
        var userDeviceInfo = UserDeviceModel()
        
        userDeviceInfo.username = Emailtxt.text!.trimmingCharacters(in: .whitespacesAndNewlines)
        userDeviceInfo.password = Pwdtxt.text!.trimmingCharacters(in: .whitespacesAndNewlines)
        
        let deviceInfo = self.createDeviceInfoObject()
        userDeviceInfo.deviceId = deviceInfo.deviceId
        userDeviceInfo.deviceToken = deviceInfo.deviceToken
        userDeviceInfo.deviceType = deviceInfo.deviceType
        
        return userDeviceInfo
    }
    
    // MARK: - Web Service Calls
    
    /// Web service call to sign in and get user token
    func callSignInWebService() {
        
        let userDeviceInfo = createUserModel()
        
        self.signIn(userDeviceInfo, withHandler: { (userDetails, isFromCache)  in
            guard let userInfo = userDetails else { return }
        }) { (error) in
        }
    }
}
*/




 */*/
