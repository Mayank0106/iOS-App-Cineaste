//
//  RegisterViewController.swift
//  Zepplin
//
//  Created by Mayank Sharma on 26/02/20.
//  Copyright © 2020 Mayank Sharma. All rights reserved.
//

import UIKit
import FirebaseAuth
import Firebase

class RegisterViewController: UIViewController, UITextFieldDelegate {
    
    
    @IBOutlet weak var FirstNametxt: UITextField!
    @IBOutlet weak var LastName: UITextField!
    @IBOutlet weak var EMLtxt: UITextField!
    @IBOutlet weak var Pwddtxt: UITextField!
    
    @IBOutlet weak var Cnfmpwd: UITextField!
    @IBOutlet weak var lbldesc: UILabel!
    @IBOutlet weak var lbldesc1: UILabel!
   
    @IBOutlet weak var firstname: UITextField!
    
    @IBOutlet weak var Cnfm: UITextField!
    @IBOutlet weak var pwd: UITextField!
    @IBOutlet weak var eml: UITextField!
    @IBOutlet weak var lastname: UITextField!
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
          self.navigationController?.isNavigationBarHidden = true
        linetextfield()
      FirstNametxt.delegate = self
      LastName.delegate = self
        EMLtxt.delegate = self
        Pwddtxt.delegate = self
        Cnfmpwd.delegate = self
    }
    
   func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.view.endEditing(true)
        return false
    }
    
  
    
        
        
    
    //Check the fields and Validate the data is coorct. Otherwise it will display error message
    
    func validateFields() -> String? {
        
        
        //Check that all fields are filled in
        
        if
         FirstNametxt.text?.trimmingCharacters(in: .whitespacesAndNewlines) == "" ||
            
            LastName.text?.trimmingCharacters(in: .whitespacesAndNewlines) == "" ||
            
              EMLtxt.text?.trimmingCharacters(in: .whitespacesAndNewlines) == "" ||
              Cnfmpwd.text?.trimmingCharacters(in: .whitespacesAndNewlines) == "" ||
            
            Pwddtxt.text?.trimmingCharacters(in: .whitespacesAndNewlines) == ""  {
                
            
            return "Please fill in all fields."
            }
        
        
        return nil
    }
    
    
    
    @IBAction func signInn(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
        
        
    }
    
    
    @IBAction func Regis(_ sender: Any) {
        
        let error = validateFields()
        
        if error != nil  {
            
            // There's something wrong with the fields show error message
            
            showError(_message: error!)
            
        }
        else {
            
            //Create cleaned version of the data
            let firstname = FirstNametxt.text!.trimmingCharacters(in: .whitespacesAndNewlines)
            let lastname = LastName.text!.trimmingCharacters(in: .whitespacesAndNewlines)
            let email = EMLtxt.text!.trimmingCharacters(in: .whitespacesAndNewlines)
            let password = Pwddtxt.text!.trimmingCharacters(in: .whitespacesAndNewlines)
            let Confirm = Cnfmpwd.text!.trimmingCharacters(in: .whitespacesAndNewlines)
            
            // create the User
            
            Auth.auth().createUser(withEmail: email, password: password)  { (result, err) in
                //Check for errors
                if err != nil {
                    // There was an error creating the user
                    self.showError(_message: "Error creating user")
                    
                }
                
                else {
                    // User created successfully, Now Store the first name and last name
                    let db = Firestore.firestore()
                    
                    db.collection("users").addDocument(data: ["firstname":firstname, "lastname":lastname, "uid": result!.user.uid ]) { (error) in
                        
                        if error != nil {
                            //Show error message
                            self.showError(_message: "Error saving using data")
                        }
                    }
                    // Transition to HomeScreen
                    self.transitionToHome()
                }
            }
            
            
            // Transition to the home Screen
            
            
        }
        
        /*lbldesc.isHidden = true
        lbldesc1.isHidden = true
        guard let email = EMLtxt.text, EMLtxt.text?.characters.count !=
            0 else {
                lbldesc.isHidden = false
                lbldesc.text = "Please enter your Email"
                return
        }
        if isValidEmail(emailID: email) == false {
            lbldesc.isHidden = false
            lbldesc.text = "Please enter valid Email address"
        
        }*/
        
        
    }
    
    func showError(_message: String){
        lbldesc.text = _message
        lbldesc.alpha = 1
    }
    
    
    
    func transitionToHome() {
        
        let homeViewController =
            storyboard?.instantiateViewController(withIdentifier: Constants.Storyboard.homeViewController) as? HomeViewController
        
        view.window?.rootViewController = homeViewController
        view.window?.makeKeyAndVisible()
        
        
    }
   
    func linetextfield() {
        // create the bottom line
        let bottomLine = CALayer()
        let bottomLine1 = CALayer()
        let bottomLine2 = CALayer()
        let bottomLine3 = CALayer()
        let bottomLine4 = CALayer()
        
        bottomLine.frame = CGRect( x: 0, y: firstname.frame.height - 2, width: firstname.frame.width, height: 2)
         bottomLine.backgroundColor = UIColor.white.cgColor
        
        
        bottomLine1.frame = CGRect( x: 0, y: lastname.frame.height - 2, width: lastname.frame.width, height: 2)
        bottomLine1.backgroundColor = UIColor.white.cgColor
        
        
        
        
        bottomLine2.frame = CGRect( x: 0, y: eml.frame.height - 2, width: eml.frame.width, height: 2)
        bottomLine2.backgroundColor = UIColor.white.cgColor
        
        
        bottomLine3.frame = CGRect( x: 0, y: pwd.frame.height - 2, width: pwd.frame.width, height: 2)
        bottomLine3.backgroundColor = UIColor.white.cgColor
        
        
        bottomLine4.frame = CGRect( x: 0, y: Cnfm.frame.height - 2, width: Cnfm.frame.width, height: 2)
        bottomLine4.backgroundColor = UIColor.white.cgColor
        
        //Remove Border on text field
        firstname.borderStyle = .none
        lastname.borderStyle = .none
        eml.borderStyle = .none
        pwd.borderStyle = .none
        Cnfm.borderStyle = .none
        
        // Add line to the text field
        firstname.layer.addSublayer(bottomLine)
        lastname.layer.addSublayer(bottomLine1)
        eml.layer.addSublayer(bottomLine2)
        pwd.layer.addSublayer(bottomLine3)
        Cnfm.layer.addSublayer(bottomLine4)
        // image on left side
        firstname.leftViewMode = UITextFieldViewMode.always
        let imageView = UIImageView(frame: CGRect(x: 0, y: 0, width: 20, height: 20))
        let image = UIImage(named: "whitefirsttt")
        imageView.image = image
        firstname.leftView = imageView
        
        
        lastname.leftViewMode = UITextFieldViewMode.always
        let imageView1 = UIImageView(frame: CGRect(x: 0, y: 0, width: 20, height: 20))
        let image1 = UIImage(named: "whitefirsttt")
        imageView1.image = image1
        lastname.leftView = imageView1
        
        
        eml.leftViewMode = UITextFieldViewMode.always
        let imageView2 = UIImageView(frame: CGRect(x: 0, y: 0, width: 20, height: 20))
        let image2 = UIImage(named: "emaill")
        imageView2.image = image2
        eml.leftView = imageView2
        
        
        pwd.leftViewMode = UITextFieldViewMode.always
        let imageView3 = UIImageView(frame: CGRect(x: 0, y: 0, width: 20, height: 20))
        let image3 = UIImage(named: "passwordd")
        imageView3.image = image3
        pwd.leftView = imageView3
        
        
        Cnfm.leftViewMode = UITextFieldViewMode.always
        let imageView4 = UIImageView(frame: CGRect(x: 0, y: 0, width: 20, height: 20))
        let image4 = UIImage(named: "passwordd")
        imageView4.image = image4
        Cnfm.leftView = imageView4
        
        
        
        
    }
    
    
    
    
    
   /* func isValidEmail(emailID:String) ->Bool {
        let  emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9,-]+\\.[A-Za-z]{2,}"
        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailTest.evaluate(with: emailID)
    }*/
    
 
    
}

