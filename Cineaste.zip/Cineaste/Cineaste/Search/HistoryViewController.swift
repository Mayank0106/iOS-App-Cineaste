//
//  HistoryViewController.swift
//  Cineaste
//
//  Created by Mayank Sharma on 23/05/20.
//  Copyright © 2020 Mayank Sharma. All rights reserved.
//

import UIKit
import ObjectMapper
class HistoryViewController: UIViewController, UITableViewDataSource,UITableViewDelegate, iCarouselDelegate, iCarouselDataSource {
    final let url = URL(string: "https://api.themoviedb.org/3/tv/airing_today?api_key=8efe9663738c034166653c595112a697&language=en-US&page=1")
    
    final let url1 = URL(string: "https://api.themoviedb.org/3/tv/on_the_air?api_key=8efe9663738c034166653c595112a697&language=en-US&page=1")
    
    
    final let url2 = URL(string: "https://api.themoviedb.org/3/tv/popular?api_key=8efe9663738c034166653c595112a697&language=en-US&page=1")
    
    
    final let url3 = URL(string: "https://api.themoviedb.org/3/tv/top_rated?api_key=8efe9663738c034166653c595112a697&language=en-US&page=1")
    
    
    private var tv = [TVModal]()
    private var tvair = [TVModal]()
    private var tvpopular = [TVModal]()
    private var tvtoprated = [TVModal]()
    var index = 0
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var iCarouselView: iCarousel! 
    override func viewDidLoad() {
        super.viewDidLoad()
          tvjson()
        tvairjson()
        tvPopularjson()
        tvtopratedjson()
        self.setNavBar(title: "TV")
        
        
        
        iCarouselView.type = .rotary
        iCarouselView.autoscroll = -0.2
        iCarouselView.contentMode = .scaleAspectFill
        iCarouselView.isPagingEnabled = true
        // Do any additional setup after loading the view.
    }
   
    // tv API
    func tvjson() {
        guard let downloadURL = url else { return }
        URLSession.shared.dataTask(with: downloadURL) { data, urlResponse, error in
            guard let dataObject = data, error == nil, urlResponse != nil else {
                
                print("Something is wrong")
                
                return
                
            }
            
            
            
            print("downloaded")
            do
            {
                let json = try JSONSerialization.jsonObject(with: dataObject, options: []) as? [String : Any]
                /* let jsonData = json(using: .utf8)!*/
                guard let jsonObj = json else { return }
                var userObj = TestModaltv()
                userObj.page = jsonObj["page"] as? Int
                userObj.total_results = jsonObj["total_results"] as? Int
                userObj.total_pages = jsonObj["total_pages"] as? Int
                
                
                if let jsonResponse = jsonObj["results"] as? NSArray, let arrOfDict = jsonResponse as? [[String : Any]] {
                    let respVo = Mapper<TVModal>().mapArray(JSONArray: arrOfDict)
                    print("respVo \(respVo)")
                    userObj.tv = respVo
                    self.tv = respVo
                    self.iCarouselView.delegate = self
                    self.iCarouselView.dataSource = self
                    self.iCarouselView.reloadData()
                    
                }
                
                
                
                
                print("jsonResponse \t userObj", jsonObj, userObj)
                
                
                /*let decoder = JSONDecoder()
                 let results = try decoder.decode(Test123.self, from: dataObject)
                 print(results)*/
                
                DispatchQueue.main.async {
                    self.tableView.reloadData()
                }
                
                
                
            }
            catch{
                print("Something wrong after downloaded")
                
            }
            
            }.resume()
        
    }
    
    
    // On the Air TV API
    
    func tvairjson() {
        guard let downloadURL = url1 else { return }
        URLSession.shared.dataTask(with: downloadURL) { data, urlResponse, error in
            guard let dataObject = data, error == nil, urlResponse != nil else {
                
                print("Something is wrong")
                
                return
                
            }
            
            
            
            print("downloaded")
            do
            {
                let json = try JSONSerialization.jsonObject(with: dataObject, options: []) as? [String : Any]
                /* let jsonData = json(using: .utf8)!*/
                guard let jsonObj = json else { return }
                var userObj = TestModaltv()
                userObj.page = jsonObj["page"] as? Int
                userObj.total_results = jsonObj["total_results"] as? Int
                userObj.total_pages = jsonObj["total_pages"] as? Int
                
                
                if let jsonResponse = jsonObj["results"] as? NSArray, let arrOfDict = jsonResponse as? [[String : Any]] {
                    let respVo = Mapper<TVModal>().mapArray(JSONArray: arrOfDict)
                    print("respVo \(respVo)")
                    userObj.tv = respVo
                    self.tvair = respVo
                    
                }
                
                
                
                
                print("jsonResponse \t userObj", jsonObj, userObj)
                
                
                /*let decoder = JSONDecoder()
                 let results = try decoder.decode(Test123.self, from: dataObject)
                 print(results)*/
                
                DispatchQueue.main.async {
                    self.tableView.reloadData()
                }
                
                
                
            }
            catch{
                print("Something wrong after downloaded")
                
            }
            
            }.resume()
        
    }
    
    
    // TV Popular API
    
    func tvPopularjson() {
        guard let downloadURL = url2 else { return }
        URLSession.shared.dataTask(with: downloadURL) { data, urlResponse, error in
            guard let dataObject = data, error == nil, urlResponse != nil else {
                
                print("Something is wrong")
                
                return
                
            }
            
            
            
            print("downloaded")
            do
            {
                let json = try JSONSerialization.jsonObject(with: dataObject, options: []) as? [String : Any]
                /* let jsonData = json(using: .utf8)!*/
                guard let jsonObj = json else { return }
                var userObj = TestModaltv()
                userObj.page = jsonObj["page"] as? Int
                userObj.total_results = jsonObj["total_results"] as? Int
                userObj.total_pages = jsonObj["total_pages"] as? Int
                
                
                if let jsonResponse = jsonObj["results"] as? NSArray, let arrOfDict = jsonResponse as? [[String : Any]] {
                    let respVo = Mapper<TVModal>().mapArray(JSONArray: arrOfDict)
                    print("respVo \(respVo)")
                    userObj.tv = respVo
                    self.tvpopular = respVo
                    
                }
                
                
                
                
                print("jsonResponse \t userObj", jsonObj, userObj)
                
                
                /*let decoder = JSONDecoder()
                 let results = try decoder.decode(Test123.self, from: dataObject)
                 print(results)*/
                
                DispatchQueue.main.async {
                    self.tableView.reloadData()
                }
                
                
                
            }
            catch{
                print("Something wrong after downloaded")
                
            }
            
            }.resume()
        
    }
    
    //TV Top rated API
    
    func tvtopratedjson() {
        guard let downloadURL = url3 else { return }
        URLSession.shared.dataTask(with: downloadURL) { data, urlResponse, error in
            guard let dataObject = data, error == nil, urlResponse != nil else {
                
                print("Something is wrong")
                
                return
                
            }
            
            
            
            print("downloaded")
            do
            {
                let json = try JSONSerialization.jsonObject(with: dataObject, options: []) as? [String : Any]
                /* let jsonData = json(using: .utf8)!*/
                guard let jsonObj = json else { return }
                var userObj = TestModaltv()
                userObj.page = jsonObj["page"] as? Int
                userObj.total_results = jsonObj["total_results"] as? Int
                userObj.total_pages = jsonObj["total_pages"] as? Int
                
                
                if let jsonResponse = jsonObj["results"] as? NSArray, let arrOfDict = jsonResponse as? [[String : Any]] {
                    let respVo = Mapper<TVModal>().mapArray(JSONArray: arrOfDict)
                    print("respVo \(respVo)")
                    userObj.tv = respVo
                    self.tvtoprated = respVo
                    
                }
                
                
                
                
                print("jsonResponse \t userObj", jsonObj, userObj)
                
                
                /*let decoder = JSONDecoder()
                 let results = try decoder.decode(Test123.self, from: dataObject)
                 print(results)*/
                
                DispatchQueue.main.async {
                    self.tableView.reloadData()
                }
                
                
                
            }
            catch{
                print("Something wrong after downloaded")
                
            }
            
            }.resume()
        
    }
    
    
    
    
    
    
    
    
    
    
    
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 4
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "Cell") as?  HistoryTableViewCell else {return UITableViewCell() }
        
        //Will not highlight the cell when selected
        cell.selectionStyle = .none
      
        cell.tv = self.tv
        cell.tvair = self.tvair
        cell.tvpopular = self.tvpopular
        cell.tvtoprated = self.tvtoprated
        cell.itemType = indexPath.section
        cell.MycollectionView.reloadData()
     
        //when cancelAction
        cell.callDetailAction {(section, rowIndex) in
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let vc = storyboard.instantiateViewController(withIdentifier: "HistoryTVInfoViewController") as? HistoryTVInfoViewController
            switch section {
            case 0:
                vc?.tv = self.tv[rowIndex]
            case 1:
                vc?.tv = self.tvair[rowIndex]
            case 2:
                vc?.tv = self.tvpopular[rowIndex]
            case 3:
                vc?.tv = self.tvtoprated[rowIndex]
            default: break
            }
            self.navigationController?.pushViewController(vc!, animated: true)
        }
        return cell
    }
    
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 250
    }
    
    // MARK: Table header
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let vwForSection = UIView()
        
        vwForSection.frame = CGRect(x:0 , y:0, width: 150, height: 30)
        vwForSection.backgroundColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1)
        let lblForSection = UILabel()
        let lblForSection1 = UILabel()
        index = section
        
        lblForSection.frame = CGRect(x:10 , y:0, width: 150, height: 30)
        lblForSection.textColor = .yellow
        lblForSection.font = UIFont.systemFont(ofSize: 15.0)
        
        lblForSection1.frame = CGRect(x:360 , y:0, width: 150, height: 30)
        lblForSection1.textColor = .yellow
        lblForSection1.font = UIFont.systemFont(ofSize: 15.0)
        
        switch section {
        case 0:
            lblForSection.text = ("Airing Today")
            lblForSection1.text = ("More")
            let tap = UITapGestureRecognizer(target: self, action: #selector(HistoryViewController.tapFunction))
            lblForSection1.isUserInteractionEnabled = true
            lblForSection1.addGestureRecognizer(tap)
            
        case 1:
            lblForSection.text = ("On The Air")
            lblForSection1.text = ("More")
            let tap = UITapGestureRecognizer(target: self, action: #selector(HistoryViewController.tapFunction))
            lblForSection1.isUserInteractionEnabled = true
            lblForSection1.addGestureRecognizer(tap)
            
        case 2:
            lblForSection.text = ("Popular")
            lblForSection1.text = ("More")
            let tap = UITapGestureRecognizer(target: self, action: #selector(HistoryViewController.tapFunction))
            lblForSection1.isUserInteractionEnabled = true
            lblForSection1.addGestureRecognizer(tap)
            
        case 3:
            lblForSection.text = ("Top Rated")
            lblForSection1.text = ("More")
            let tap = UITapGestureRecognizer(target: self, action: #selector(HistoryViewController.tapFunction))
            lblForSection1.isUserInteractionEnabled = true
            lblForSection1.addGestureRecognizer(tap)
            
        default:
            print(section)
        }
        
        vwForSection.addSubview(lblForSection)
        vwForSection.addSubview(lblForSection1)
        
        return vwForSection
        
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 44
    }
    
    
    @objc func tapFunction(sender:UITapGestureRecognizer) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "TVListingViewController") as? TVListingViewController
        vc?.tv = tv
         vc?.tvair = tvair
        vc?.tvpopular = tvpopular
        vc?.tvtoprated = tvtoprated
       
        
        self.navigationController?.pushViewController(vc!, animated: true)
    }
    
    
    
    //iCaraousel
    
    func numberOfItems(in carousel: iCarousel) -> Int {
        return tv.count
    }
    
    func carousel(_ carousel: iCarousel, viewForItemAt index: Int, reusing view: UIView?) -> UIView {
        var itemView: UIImageView?
        if view == nil {
            itemView = UIImageView(frame: CGRect(x: 0, y: 0, width: UIScreen.main.bounds.width - 40, height: 150))
            itemView?.contentMode = .scaleAspectFill
            itemView?.layer.borderWidth = 3.0
            itemView?.layer.masksToBounds = true
            itemView?.layer.cornerRadius = 8.0
            itemView?.layer.borderColor = UIColor.white.cgColor
        } else {
            itemView = view as? UIImageView
        }
        itemView?.clipsToBounds = true
        
        let poster_path =  tv[index].poster_path ?? ""
        if let imageURL = URL(string: Constants.baseUrl + poster_path){
            
            DispatchQueue.global().async {
                let data = try? Data(contentsOf: imageURL)
                if let data = data {
                    let image = UIImage(data: data)
                    DispatchQueue.main.async {
                        itemView?.image = image
                        
                    }
                }
            }
            
        }
        
        return itemView ?? UIImageView()
        
        
    }
    
    func carousel(_ carousel: iCarousel, didSelectItemAt index: Int) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "HistoryTVInfoViewController") as? HistoryTVInfoViewController
        
        vc?.tv = tv[index]
        
        self.navigationController?.pushViewController(vc!, animated: true)
    }
    
    
    
    
    
}



