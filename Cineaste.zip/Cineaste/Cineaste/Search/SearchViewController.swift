//
//  SearchViewController.swift
//  Cineaste
//
//  Created by Mayank Sharma on 23/05/20.
//  Copyright © 2020 Mayank Sharma. All rights reserved.
//

import UIKit
import ObjectMapper
class SearchViewController: UIViewController, UITableViewDataSource, UISearchBarDelegate, UITableViewDelegate  {

    final let url = URL(string: "https://api.themoviedb.org/3/movie/popular?api_key=8efe9663738c034166653c595112a697&language=en-US&page=1")
    private var results = [ResultModal]()
    
    var downnloadJson = [ResultModal]()
    var Search2 = [ResultModal]()
    var result =  ResultModal()

     
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var tableView: UITableView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
//        var url1 = "https://api.themoviedb.org/3/search/movie?api_key=8efe9663738c034166653c595112a697&language=en-US&query={movie_name}&page=1&include_adult = false"
//        if let movieName = self.result.originalTitle {
//            url1 = url1.replacingOccurrences(of: "{movie_name}", with:"\(movieName)", options: .literal, range: nil)
//        }
//        print("URL IS", url1)
//        Searchbar(urlString: url1)
        downloadJson()
        self.setNavBar(title: "Discover Movies")
        
    }
    
   
   
    
    func SearchbarTapped(urlString: String) {
       
        let urlNew = URL(string: urlString)
        
        guard let downloadURL = urlNew else { return }
      
        URLSession.shared.dataTask(with: downloadURL) { data, urlResponse, error in
            guard let dataObject = data, error == nil, urlResponse != nil else {
                print("Something is wrong")
                return
            }
            print("downloaded")
            
            do
            {
                let json = try JSONSerialization.jsonObject(with: dataObject, options: []) as? [String : Any]
                
                print("respVo \(json)")
                
                /* let jsonData = json(using: .utf8)!*/
                guard let jsonObj = json else { return }
                var userObj = TestModal()
                userObj.page = jsonObj["page"] as? Int
                userObj.total_results = jsonObj["total_results"] as? Int
                userObj.total_pages = jsonObj["total_pages"] as? Int
                
                if let jsonResponse = jsonObj["results"] as? NSArray, let arrOfDict = jsonResponse as? [[String : Any]] {
                    let respVo = Mapper<ResultModal>().mapArray(JSONArray: arrOfDict)
                    print("respVo \(respVo)")
                    userObj.results = respVo
                    self.results = respVo

                    DispatchQueue.main.async {
                        print("responsee",respVo)
                        //if respVo.count > 0 {
                            self.tableView.reloadData()
                        //}
                    }
                }
                
            }
            catch {
                print("Something wrong after downloaded")
                
            }
            
            }.resume()
        
    }
    
    
    /*func loadSearchBar(result: ResultModal) {
        // (Constants.mainURL1)  \(String(describing: trailer?.id!)) \(Constants.mainURL2)
     /*   var urlString = "https://api.themoviedb.org/3/search/movie?api_key=8efe9663738c034166653c595112a697&language=en-US&query={movie_name}&page=1&include_adult=false"
        if let id = result.id {
            urlString = urlString.replacingOccurrences(of: "{movie_name", with:"\(id)", options: .literal, range: nil)
    */

        //print(" URL IS", urlString)
        
       /* let url = URL(string: urlString)
        let request = URLRequest(url: url!)*/
    }*/
    
    
  /*  private func setUpSearchBar() {
        searchBar.delegate = self
    }*/
    
  
   
    func downloadJson() {
        guard let downloadURL = url else { return }
        URLSession.shared.dataTask(with: downloadURL) { data, urlResponse, error in
            guard let dataObject = data, error == nil, urlResponse != nil else {
                
                print("Something is wrong")
                
                return
                
            }
            
            
            
            print("downloaded")
            do
            {
                let json = try JSONSerialization.jsonObject(with: dataObject, options: []) as? [String : Any]
                /* let jsonData = json(using: .utf8)!*/
                guard let jsonObj = json else { return }
                var userObj = TestModal()
                userObj.page = jsonObj["page"] as? Int
                userObj.total_results = jsonObj["total_results"] as? Int
                userObj.total_pages = jsonObj["total_pages"] as? Int
                
                
                if let jsonResponse = jsonObj["results"] as? NSArray, let arrOfDict = jsonResponse as? [[String : Any]] {
                    let respVo = Mapper<ResultModal>().mapArray(JSONArray: arrOfDict)
                    print("respVo \(respVo)")
                    userObj.results = respVo
                    self.results = respVo
                    self.downnloadJson = self.results
                }
                print("jsonResponse \t userObj", jsonObj, userObj)
                
                
                /*let decoder = JSONDecoder()
                 let results = try decoder.decode(Test123.self, from: dataObject)
                 print(results)*/
                
                DispatchQueue.main.async {
                    self.tableView.reloadData()
                }
                
                
                
            }
            catch{
                print("Something wrong after downloaded")
                
            }
            
            }.resume()
        
    }
    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return results.count
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "Cell") as? SearchCellTableViewCell else {return UITableViewCell() }
        
        //Will not highlight the cell when selected
        cell.selectionStyle = .none

        
        
        cell.lblDesc.text = " " + (results[indexPath.row].originalTitle ?? "")
        //cell.WatchImg.image = " " + (results[indexPath.row].posterPath ?? "")//
        
        let posterPath = results[indexPath.row].posterPath ?? ""
        
        if let imageURL = URL(string: Constants.baseUrl +  posterPath) {
            DispatchQueue.global().async {
                let data = try? Data(contentsOf: imageURL)
                if let data = data {
                    let image = UIImage(data: data)
                    DispatchQueue.main.async {
                        cell.WatchImg.image = image
                    }
                }
            }
        }
        
        return cell
        
    }
 
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "WatchlistMovieInfoViewController") as? WatchlistMovieInfoViewController
        vc?.results = results[indexPath.row]
        self.navigationController?.pushViewController(vc!, animated: true)
        
    }
    
    
    
    
    
    //Search Bar
   
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        
        var urlString = "https://api.themoviedb.org/3/search/movie?api_key=8efe9663738c034166653c595112a697&language=en-US&query={movie_name}&page=1&include_adult=false"
        
        //if let id = result.id {
        if let etxEmpty = searchBar.text?.isEmpty, etxEmpty {
            // Show Alert to user
        } else {
            urlString = urlString.replacingOccurrences(of: "{movie_name}", with:"\(searchBar.text!)", options: .literal, range: nil)
            
            self.SearchbarTapped(urlString: urlString)
        }
        
       
        self.searchBar.endEditing(true)
        
    }
    
    
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        
        if (searchBar.text?.isEmpty)! {
            self.results = self.downnloadJson
            self.tableView.reloadData()
        }
        
    }
    
    
    
}








